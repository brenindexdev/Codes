﻿<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <title>Rodapé - Loja de Livros</title>
    <style>
        :root {
            --primary-color: #621cd4;
            --primary-hover: #4a148c;
            --secondary-color: #7e3ce8;
            --background-color: #f8f9fa;
            --text-color: #2d3748;
            --text-muted: #718096;
            --white: #ffffff;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        .conteudo {
            flex: 1;
        }

        .rodape {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 40px 0;
            width: 100%;
            margin-top: auto;
        }

        .rodape a {
            color: var(--white);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .rodape a:hover {
            color: var(--secondary-color);
        }

        .rodape .logo-rodape img {
            max-height: 70px;
            width: auto;
            margin-bottom: 1rem;
        }

        .rodape .secao-rodape h5 {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            color: var(--white);
        }

        .rodape .secao-rodape ul {
            list-style: none;
            padding: 0;
        }

        .rodape .secao-rodape ul li {
            margin-bottom: 0.75rem;
        }

        .rodape .icones-sociais a {
            font-size: 1.5rem;
            margin-right: 1rem;
            color: var(--white);
            transition: color 0.3s ease;
        }

        .rodape .icones-sociais a:hover {
            color: var(--secondary-color);
        }

        .rodape .rodape-inferior {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
            margin-top: 20px;
            text-align: center;
        }

        .rodape .rodape-inferior p {
            margin: 0;
            color: var(--white);
        }

        @media (max-width: 768px) {
            .rodape .secao-rodape {
                margin-bottom: 2rem;
                text-align: center;
            }

            .rodape .icones-sociais {
                justify-content: center;
            }

            .rodape .row {
                flex-direction: column;
                align-items: center;
            }

            .rodape .col {
                text-align: center;
                margin-bottom: 2rem;
            }
        }
    </style>
</head>

<body>
    <footer class="rodape mt-5">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 pb-3">
                <!-- Logo e Descrição -->
                <div class="col mb-4">
                    <div class="logo-rodape">
                        <img src="img/logo2.png" alt="Logo da Loja de Livros">
                    </div>
                    <p class="text-light">
                        A Loja de Livros é o seu destino para encontrar os melhores títulos, desde clássicos até os lançamentos mais recentes. Oferecemos uma experiência de compra segura e entregas rápidas.
                    </p>
                </div>

                <!-- Links Úteis -->
                <div class="col mb-4">
                    <h5 class="secao-rodape">Links Úteis</h5>
                    <ul class="nav flex-column secao-rodape">
                        <li class="nav-item mb-2"><a href="sobre-nos.php" class="nav-link p-0 text-light">Sobre Nós</a></li>
                        <li class="nav-item mb-2"><a href="politica-privacidade.php" class="nav-link p-0 text-light">Política de Privacidade</a></li>
                        <li class="nav-item mb-2"><a href="termos-condicoes.php" class="nav-link p-0 text-light">Termos e Condições</a></li>
                        <li class="nav-item mb-2"><a href="trocas-devolucoes.php" class="nav-link p-0 text-light">Trocas e Devoluções</a></li>
                        <li class="nav-item mb-2"><a href="perguntas-frequentes.php" class="nav-link p-0 text-light">Perguntas Frequentes</a></li>
                    </ul>
                </div>

                <!-- Contato -->
                <div class="col mb-4">
                    <h5 class="secao-rodape">Contato</h5>
                    <ul class="nav flex-column secao-rodape">
                        <li class="nav-item mb-2"><i class="fas fa-map-marker-alt mr-2"></i> Rua Tal, 123 - Piracicaba, SP</li>
                        <li class="nav-item mb-2"><i class="fas fa-phone mr-2"></i> (19) 1234-5678</li>
                        <li class="nav-item mb-2"><i class="fas fa-envelope mr-2"></i> contato@naxlivraria.com</li>
                        <li class="nav-item mb-2"><i class="fas fa-clock mr-2"></i> Seg-Sex: 9h às 18h</li>
                    </ul>
                </div>

                <!-- Redes Sociais -->
                <div class="col mb-4">
                    <h5 class="secao-rodape">Siga-nos</h5>
                    <div class="icones-sociais">
                        <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                        <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="#" target="_blank"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>

            <!-- Rodapé Inferior -->
            <div class="rodape-inferior">
                <p>&copy; 2024 Loja de Livros. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS e dependências -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>

</html>