<?php
$titulo = "Loja de Livros - Detalhes";

require_once('include/conexao.php');
include_once('includes/cabecalho_site.php');

$produto = $_GET['produto'];

// Recupera os detalhes do produto
$q = "SELECT l.*, c.descricao
      FROM livros l INNER JOIN categorias c
      ON l.id_categoria = c.id
      WHERE l.codigo = '" . $produto . "'";

$r = @mysqli_query($dbc, $q);
$reg = mysqli_fetch_array($r);

$codigo = $reg["codigo"];
$nome = $reg["nome"];
$ano = $reg["ano"];
$autor = $reg["autor"];
$editora = $reg["editora"];
$nome_cat = $reg["descricao"];
$preco = $reg["preco"];
$desconto = $reg["desconto"];
$desconto_boleto = $reg["desconto_boleto"];
$max_parcelas = $reg["max_parcelas"];
$estoque = $reg["estoque"];
$min_estoque = $reg["min_estoque"];
$sinopse = $reg["sinopse"];
$valor_desconto = $preco - ($preco * $desconto) / 100;
$valor_boleto = $valor_desconto - ($valor_desconto * $desconto_boleto) / 100;

// Cálculo das parcelas
$col_esq = '';
$col_dir = '';
for ($contador = 1; $contador <= $max_parcelas; $contador++) {
    if ($contador % 2 == 1) {
        $col_esq .= $contador . ' x de R$ ' .
            number_format($valor_desconto / $contador, 2, ',', '.') . ' sem juros.<br />';
    } else {
        $col_dir .= $contador . ' x de R$ ' .
            number_format($valor_desconto / $contador, 2, ',', '.') . ' sem juros.<br />';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo; ?></title>
    <!-- Fancybox CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css" />
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        :root {
            --primary-color: #621cd4;
            --primary-hover: #4a148c;
            --secondary-color: #7e3ce8;
            --background-color: #f8f9fa;
            --border-color: #e2e8f0;
            --text-color: #2d3748;
            --text-muted: #718096;
        }

        body {
            padding-top: 110px;
        }

        /* Estilos personalizados para o SweetAlert2 */
        .swal2-popup {
            background: var(--background-color);
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            color: var(--text-color);
        }

        .swal2-title {
            color: var(--primary-color);
            font-size: 1.5rem;
            font-weight: 700;
        }

        .swal2-content {
            color: var(--text-muted);
            font-size: 1rem;
        }

        .swal2-confirm {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            border: none !important;
            border-radius: 8px !important;
            padding: 0.75rem 1.5rem !important;
            font-size: 1rem !important;
            font-weight: 500 !important;
            transition: all 0.3s ease !important;
        }

        .swal2-confirm:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2) !important;
        }

        .swal2-cancel {
            background: var(--background-color) !important;
            border: 1px solid var(--border-color) !important;
            border-radius: 8px !important;
            padding: 0.75rem 1.5rem !important;
            font-size: 1rem !important;
            font-weight: 500 !important;
            color: var(--text-color) !important;
            transition: all 0.3s ease !important;
        }

        .swal2-cancel:hover {
            background: var(--background-color) !important;
            border-color: var(--primary-color) !important;
            color: var(--primary-color) !important;
        }

        .back-button {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .back-button i {
            color: var(--primary-color);
            font-size: 1.25rem;
        }

        .back-button:hover {
            transform: scale(1.05);
            background: var(--white);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        .product-container {
            display: flex;
            flex-wrap: wrap;
            /* Permite que as colunas se ajustem em telas menores */
            justify-content: center;
            align-items: flex-start;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .product-details {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .product-image {
            flex: 1 1 40%;
            text-align: center;
        }

        .product-image img {
            max-width: 85%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.4);
            transition: all 0.3s ease;
        }

        .product-image img:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.8);
        }

        .product-details-right {
            flex: 1 1 55%;
        }

        .product-info {
            display: flex;
            justify-content: space-between;
            /* Espaço entre as informações e o botão/esgotado */
            align-items: flex-start;
            /* Alinhar ao topo */
            margin-bottom: 1.5rem;
        }

        .product-info-content {
            flex: 1;
            /* Ocupa o espaço restante */
        }

        .product-info h1 {
            font-size: 2rem;
            font-weight: 700;
            color: black;
            margin-bottom: 0.5rem;
            transition: all 0.2s ease;
        }

        .product-info h1:hover {
            transform: scale(1.05);
        }

        .product-info .price {
            font-size: 1.5rem;
            color: var(--text-color);
        }

        .product-info .original-price {
            text-decoration: line-through;
            color: var(--text-muted);
            font-size: 1rem;
        }

        .product-info .discounted-price {
            color: var(--primary-color);
            font-weight: 700;
        }

        .product-info .stock {
            font-size: 1rem;
            color: var(--text-muted);
            margin-bottom: 1rem;
        }

        .product-info .btn-add-to-cart {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            align-self: flex-start;
            /* Alinha o botão ao topo */
        }

        .product-info .btn-add-to-cart:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2);
        }

        .product-info .btn-add-to-cart:active {
            transform: translateY(0);
        }

        .product-description {
            margin-bottom: 1.5rem;
        }

        .product-description h2 {
            font-size: 1.5rem;
            color: black;
            font-weight: 500;
            margin-bottom: 1rem;
        }

        .product-description p {
            font-size: 1rem;
            color: var(--text-color);
            line-height: 1.6;
        }

        .product-specs {
            margin-bottom: 1.5rem;
        }

        .product-specs h2 {
            font-size: 1.5rem;
            color: black;
            font-weight: 500;
            margin-bottom: 1rem;
        }

        .product-specs p {
            font-size: 1rem;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .payment-options {
            margin-bottom: 1.5rem;
        }

        .payment-options h2 {
            font-size: 2rem;
            color: var(--text-color);
            margin-bottom: 1rem;
        }

        .payment-options p {
            font-size: 1rem;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            text-decoration: none !important;
            color: black !important;
            margin-bottom: 20px;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .product-info .out-of-stock {
            background: #FEE2E2;
            color: #DC2626;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            align-self: flex-start;
            /* Alinha o aviso ao topo */
        }

        @media (max-width: 991px) {
            .product-image img {
                max-width: 100%;
            }
        }

        @media (max-width: 833px) {
            .product-container {
                flex-direction: column;
                /* Coloca as colunas em uma única coluna */
                gap: 1rem;
            }

            .product-image,
            .product-details-right {
                flex: 1 1 100%;
                /* Ocupa 100% da largura em telas menores */
            }

            .product-info h1 {
                font-size: 1.75rem;
                /* Reduz o tamanho do título */
            }

            .product-info .price {
                font-size: 1.25rem;
                /* Reduz o tamanho do preço */
            }

            .product-description h2,
            .product-specs h2,
            .payment-options h2,
            .delivery-options h2,
            .observations h2 {
                font-size: 1.5rem;
                /* Reduz o tamanho dos subtítulos */
            }
        }

        @media (max-width: 480px) {
            .product-info h1 {
                font-size: 1.5rem;
                /* Título ainda menor para telas muito pequenas */
            }

            .product-info .price {
                font-size: 1rem;
                /* Preço ainda menor para telas muito pequenas */
            }

            .product-description h2,
            .product-specs h2,
            .payment-options h2,
            .delivery-options h2,
            .observations h2 {
                font-size: 1.25rem;
                /* Subtítulos ainda menores */
            }
        }
    </style>
</head>

<body>
    <div class="container my-4">
        <div class="back-button" onclick="window.history.back()">
            <i class="fas fa-arrow-left"></i>
        </div>

        <div class="product-details">
            <div class="product-container">
                <!-- Coluna da esquerda: Imagem -->
                <div class="product-image">
                    <a href="produtos/<?= $codigo; ?>.jpg" data-fancybox="image-<?= $codigo; ?>" data-caption="<?= $nome; ?>">
                        <img src="produtos/<?= $codigo; ?>.jpg" alt="<?= $nome; ?>">
                    </a>
                </div>

                <!-- Coluna da direita: Detalhes do produto -->
                <div class="product-details-right">
                    <div class="product-info">
                        <!-- Conteúdo das informações (nome, preço, estoque) -->
                        <div class="product-info-content">
                            <h1><?= $nome; ?></h1>
                            <div class="price">
                                <span class="original-price">De: R$ <?= number_format($preco, 2, ',', '.'); ?></span>
                                <span class="discounted-price">Por: R$ <?= number_format($valor_desconto, 2, ',', '.'); ?></span>
                            </div>
                            <div class="stock">
                                <?php if ($estoque > $min_estoque): ?>
                                    <span>Disponível em estoque</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Botão "Adicionar ao Carrinho" ou Aviso "Esgotado" -->
                        <?php if ($estoque > $min_estoque): ?>
                            <button class="btn-add-to-cart" onclick="verificarLogin(event)"><strong>Adicionar ao Carrinho</strong></button>
                        <?php else: ?>
                            <span class="out-of-stock">Indisponível</span>
                        <?php endif; ?>
                    </div>

                    <!-- Sinopse e Dados Técnicos -->
                    <div class="product-description">
                        <h2>Sinopse</h2>
                        <p><?= $sinopse; ?></p>
                    </div>

                    <div class="product-specs">
                        <h2>Dados Técnicos</h2>
                        <p><strong>Código:</strong> <?= $codigo; ?></p>
                        <p><strong>Categoria:</strong> <?= $nome_cat; ?></p>
                        <p><strong>Ano:</strong> <?= $ano; ?></p>
                        <p><strong>Autor:</strong> <?= $autor; ?></p>
                        <p><strong>Editora:</strong> <?= $editora; ?></p>
                    </div>
                </div>
            </div>

            <!-- Formas de pagamento e entrega (abaixo das colunas) -->
            <div class="payment-options">
                <h2>Formas de Pagamento</h2>
                <p><strong>Parcelamento no cartão de crédito:</strong></p>
                <div class="row">
                    <div class="col-md-6">
                        <?= $col_esq; ?>
                    </div>
                    <div class="col-md-6">
                        <?= $col_dir; ?>
                    </div>
                </div>
                <p><strong>Pague com boleto e ganhe <?= number_format($desconto_boleto, 2, ',', '.'); ?>% de desconto:</strong> R$ <?= number_format($valor_boleto, 2, ',', '.'); ?></p>
                <p><strong>Formas de pagamento:</strong></p>
                <img src="img/banner_formapag.jpg" alt="Formas de pagamento" class="img-fluid">
            </div>

            <div class="delivery-options">
                <h2>Formas de Entrega</h2>
                <p>2 dias úteis para o estado de São Paulo. <br>5 dias úteis para os demais estados.</p>
            </div>

            <div class="observations">
                <h2>Observações</h2>
                <p>As mercadorias adquiridas serão despachadas, via Sedex, no primeiro dia útil após a comprovação de pagamento, estando a entrega condicionada à disponibilidade de estoque.</p>
            </div>
        </div>
    </div>

    <!-- Fancybox JS -->
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Inicializar Fancybox
        Fancybox.bind("[data-fancybox]", {
            Thumbs: {
                autoStart: false, // Desativa miniaturas
            },
            Toolbar: {
                display: {
                    left: [], // Remove a barra de informações
                    middle: ["zoomIn", "zoomOut", "toggle1to1", "rotateCCW", "rotateCW"], // Botões de zoom e rotação
                    right: ["close"], // Mantém apenas o botão de fechar
                },
            },
        });

        // Função para abrir o Fancybox manualmente
        function abrirFancybox(codigo, nome) {
            Fancybox.show([{
                src: `produtos/${codigo}.jpg`,
                caption: nome,
            }, ]);
        }

        // Função para verificar login antes de adicionar ao carrinho
        function verificarLogin(event) {
            event.preventDefault(); // Impede o comportamento padrão do botão

            <?php if (!isset($_SESSION['usuario_id'])): ?>
                Swal.fire({
                    title: 'Você não está logado!',
                    text: 'Crie uma conta ou entre para adicionar ao carrinho.',
                    icon: 'warning',
                    confirmButtonText: 'Entrar',
                    showCancelButton: true,
                    cancelButtonText: 'Cancelar',
                    customClass: {
                        popup: 'swal2-popup',
                        title: 'swal2-title',
                        content: 'swal2-content',
                        confirmButton: 'swal2-confirm',
                        cancelButton: 'swal2-cancel',
                    },
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "include/login_cadastro.php";
                    }
                });
            <?php else: ?>
                window.location.href = "cesta.php?produto=<?= $codigo; ?>&inserir=S";
            <?php endif; ?>
        }
    </script>

    <?php include_once('includes/rodape.php'); ?>
</body>

</html>