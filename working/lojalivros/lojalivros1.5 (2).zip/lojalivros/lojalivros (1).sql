-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 23/01/2025 às 17:01
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `lojalivros`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadcli`
--

CREATE TABLE `cadcli` (
  `id` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `sobrenome` varchar(80) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `rg` varchar(14) NOT NULL,
  `sexo` char(1) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `end_nome` varchar(80) NOT NULL,
  `end_num` varchar(10) NOT NULL,
  `end_comp` varchar(100) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `bairro` varchar(50) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `uf` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `cadcli`
--

INSERT INTO `cadcli` (`id`, `nome`, `sobrenome`, `cpf`, `rg`, `sexo`, `email`, `senha`, `end_nome`, `end_num`, `end_comp`, `cep`, `bairro`, `cidade`, `uf`) VALUES
(28, 'Breno', 'Domingues', '49641063812', '13478472830', 'M', 'brenosilveiradomingues@gmail.com', '$2y$10$MoPNBwOpyFza4au1n.f8FOnQSLiLEGXUtvTbnf4jKZ0fcnGcnLDAq', 'Rua Niterói', '45', 'Casa', '13403304', 'Glebas Califórnia', 'Piracicaba', 'SP'),
(36, 'José', 'Carlos Almeida', '63459321245', '32966199012', 'M', 'jcalmeida@outlook.com', '$2y$10$U5ltErbxeInaE5KA1UsjB.0vHqxf1Rba14ODReeogn6vf6Jb4Zd9e', 'Rua das Andorinhas', '689', 'Casa', '7908276', 'Jardim Europa', 'Piracicaba', 'MS'),
(37, 'Miguel', 'Domingues', '12345678900', '13478472830', 'M', 'miguelsdomingues240413@gmail.com', '$2y$10$1dZxV8iCfFVpv7dwkAUWo.QkW/hr7nMNmL9VO7/OUgGBHwM2iNm4m', 'Rua Niterói', '45', 'Casa', '13403304', 'Glebas Califórnia', 'Piracicaba', 'SP'),
(38, 'Andréa', 'Silveira Domingues', '26773156882', '295351810', 'F', 'deiasdomingues@gmail.com', '$2y$10$aVIwr0nlMc1XjU3IAgYpJ.2knw4l/wOdhiL3eSJ0hE4.C3fp3MNF.', 'Rua Niterói', '45', 'Casa', '13403304', 'Glebas Califórnia', 'Piracicaba', 'SP');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadesc`
--

CREATE TABLE `cadesc` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `sobrenome` varchar(100) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `rg` varchar(12) NOT NULL,
  `sexo` char(1) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `end_nome` varchar(255) NOT NULL,
  `end_num` varchar(10) NOT NULL,
  `end_comp` varchar(100) DEFAULT NULL,
  `cep` varchar(9) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `uf` char(2) NOT NULL,
  `data_cad` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `cadesc`
--

INSERT INTO `cadesc` (`id`, `nome`, `sobrenome`, `cpf`, `rg`, `sexo`, `email`, `senha`, `end_nome`, `end_num`, `end_comp`, `cep`, `bairro`, `cidade`, `uf`, `data_cad`) VALUES
(1, 'Escritor', 'Teste', '12345678900', '12345678', 'M', 'testeesc@gmail.com', '$2y$10$2U8BDi/1a2PounKNUzYWUOK4k/.2L/Uc/yJxL0USicS94Z9gQq.3.', 'Rua Niterói', '45', 'Casa', '13403304', 'Glebas Califórnia', 'Piracicaba', 'MG', '2025-01-23 12:49:11');

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `descricao` varchar(50) NOT NULL,
  `status` char(1) DEFAULT 'A',
  `data_inc` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `categorias`
--

INSERT INTO `categorias` (`id`, `descricao`, `status`, `data_inc`) VALUES
(1, 'Romance', '', '0000-00-00 00:00:00'),
(2, 'Ficção Científica', '', '0000-00-00 00:00:00'),
(3, 'Fantasia', '', '0000-00-00 00:00:00'),
(4, 'Terror', '', '0000-00-00 00:00:00'),
(5, 'Suspense', '', '0000-00-00 00:00:00'),
(6, 'Infantil', '', '0000-00-00 00:00:00'),
(7, 'Autobiografia', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_do_pedido`
--

CREATE TABLE `itens_do_pedido` (
  `id` int(11) NOT NULL,
  `num_ped` varchar(20) NOT NULL,
  `codigo` varchar(20) DEFAULT NULL,
  `nome` varchar(60) NOT NULL,
  `qt` int(11) NOT NULL,
  `preco` decimal(18,2) NOT NULL,
  `preco_boleto` decimal(18,2) NOT NULL,
  `peso` decimal(9,3) NOT NULL,
  `desconto` int(11) NOT NULL,
  `desconto_boleto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `itens_do_pedido`
--

INSERT INTO `itens_do_pedido` (`id`, `num_ped`, `codigo`, `nome`, `qt`, `preco`, `preco_boleto`, `peso`, `desconto`, `desconto_boleto`) VALUES
(88, '22.012', 'FC001', 'Duna', 2, 89.90, 76.42, 0.000, 13, 15),
(89, '22.012', 'SUS003', 'O Código Da Vinci', 1, 79.90, 67.92, 0.000, 56, 15),
(90, '23.153', 'ROM011', 'Livro Teste', 2, 99.90, 74.93, 0.000, 15, 25),
(93, '24.160', 'FAN001', 'O Senhor dos Anéis: A Sociedade do Anel', 1, 89.90, 76.42, 0.000, 10, 15);

-- --------------------------------------------------------

--
-- Estrutura para tabela `livros`
--

CREATE TABLE `livros` (
  `id` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `destaque` enum('S','N') NOT NULL DEFAULT 'N',
  `nome` varchar(255) NOT NULL,
  `ano` varchar(10) DEFAULT NULL,
  `id_categoria` int(11) NOT NULL,
  `autor` varchar(255) DEFAULT NULL,
  `editora` varchar(255) DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `desconto` decimal(5,2) DEFAULT 0.00,
  `desconto_boleto` decimal(5,2) DEFAULT 0.00,
  `max_parcelas` int(11) DEFAULT 1,
  `estoque` int(11) DEFAULT 0,
  `min_estoque` int(11) DEFAULT 10,
  `data_cad` timestamp NOT NULL DEFAULT current_timestamp(),
  `sinopse` text DEFAULT NULL,
  `escritor_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `livros`
--

INSERT INTO `livros` (`id`, `codigo`, `destaque`, `nome`, `ano`, `id_categoria`, `autor`, `editora`, `preco`, `desconto`, `desconto_boleto`, `max_parcelas`, `estoque`, `min_estoque`, `data_cad`, `sinopse`, `escritor_id`) VALUES
(1, 'FC001', 'S', 'Duna', '1965', 2, 'Frank Herbert', 'Editora Aleph', 89.90, 13.00, 15.00, 12, 50, 10, '2005-12-30 03:00:00', 'Em um futuro distante, o planeta Arrakis é o único lugar onde a especiaria melange, a substância mais valiosa do universo, pode ser encontrada. Paul Atreides, herdeiro de uma família nobre, é enviado a Arrakis para administrar o planeta, mas logo se vê envolvido em uma trama política e religiosa que pode mudar o destino da humanidade. A obra explora temas como ecologia, poder e sobrevivência em um mundo hostil.', 0),
(2, 'FC002', 'N', '1984', '1949', 2, 'George Orwell', 'Companhia das Letras', 59.90, 5.00, 10.00, 6, 100, 10, '2023-10-01 03:00:00', 'Em um regime totalitário, o Grande Irmão controla todos os aspectos da vida dos cidadãos. Winston Smith, um funcionário do Partido, começa a questionar o sistema e se rebela contra a opressão, mantendo um diário secreto e se envolvendo com Julia, uma colega de trabalho. A obra é um alerta sobre os perigos do autoritarismo e da vigilância constante.', 0),
(3, 'FC003', 'N', 'Neuromancer', '1984', 2, 'William Gibson', 'Aleph', 75.00, 48.00, 15.00, 10, 30, 10, '2018-06-03 03:00:00', 'Case, um hacker talentoso, é contratado por uma misteriosa entidade para realizar um roubo no ciberespaço. A missão o leva a um mundo de inteligências artificiais, corporações poderosas e realidades virtuais. Considerado o precursor do gênero cyberpunk, o livro explora a relação entre humanos e tecnologia.', 0),
(4, 'FC004', 'N', 'Fundação', '1951', 2, 'Isaac Asimov', 'Aleph', 69.90, 28.00, 10.00, 8, 80, 10, '2015-09-14 03:00:00', 'O psicohistoriador Hari Seldon prevê o colapso do Império Galáctico e cria a Fundação, uma organização destinada a preservar o conhecimento humano e reduzir o período de escuridão que se seguirá. A saga acompanha as lutas políticas e científicas para garantir o futuro da humanidade.', 0),
(5, 'FC005', 'N', 'O Guia do Mochileiro das Galáxias', '1979', 2, 'Douglas Adams', 'Arqueiro', 55.00, 10.00, 15.00, 6, 0, 10, '2023-10-01 03:00:00', 'Arthur Dent descobre que a Terra será destruída para dar lugar a uma via expressa intergaláctica. Salvo por seu amigo Ford Prefect, ele embarca em uma jornada surreal pelo universo, encontrando alienígenas excêntricos, planetas bizarros e o significado da vida.', 0),
(6, 'FC006', 'N', 'Admirável Mundo Novo', '1932', 2, 'Aldous Huxley', 'Biblioteca Azul', 49.90, 10.00, 15.00, 6, 90, 10, '2023-10-01 03:00:00', 'Em uma sociedade futurista, os seres humanos são geneticamente modificados e condicionados para servir a um sistema de castas. Bernard Marx, um Alpha, questiona a ordem estabelecida e busca a verdade por trás do controle social.', 0),
(7, 'FC007', 'N', 'Fahrenheit 451', '1953', 2, 'Ray Bradbury', 'Biblioteca Azul', 59.90, 5.00, 10.00, 6, 80, 10, '2023-10-01 03:00:00', 'Em um mundo onde os livros são proibidos e queimados por bombeiros, Guy Montag começa a questionar seu papel na sociedade após conhecer Clarisse, uma jovem que valoriza a leitura e o pensamento crítico.', 0),
(8, 'FC008', 'N', 'Enders Game', '1985', 2, 'Orson Scott Card', 'Aleph', 69.90, 10.00, 15.00, 8, 70, 10, '2023-10-01 03:00:00', 'Andrew \"Ender\" Wiggin é uma criança prodígio recrutada para uma escola militar no espaço, onde é treinado para liderar a humanidade em uma guerra contra uma raça alienígena. A obra explora temas como estratégia, ética e a natureza da guerra.', 0),
(9, 'FC009', 'S', 'Snow Crash', '1992', 2, 'Neal Stephenson', 'Aleph', 79.90, 5.00, 10.00, 8, 60, 10, '2023-10-01 03:00:00', 'Em um futuro distópico, Hiro Protagonist é um hacker e entregador que descobre uma conspiração envolvendo uma droga digital chamada Snow Crash. A trama mistura ciberpunk, mitologia e crítica social.', 0),
(94, 'ROM001', 'S', 'Orgulho e Preconceito', '1813', 1, 'Jane Austen', 'Martin Claret', 49.90, 10.00, 15.00, 6, 120, 10, '2023-10-01 03:00:00', 'Elizabeth Bennet e Mr. Darcy superam diferenças sociais e preconceitos para se apaixonar. A obra é um clássico da literatura romântica e uma crítica à sociedade da época.', 0),
(11, 'INF001', 'S', 'O Pequeno Príncipe', '1943', 6, 'Antoine de Saint-Exupéry', 'Agir', 39.90, 5.00, 10.00, 4, 200, 10, '2023-10-01 03:00:00', 'Um piloto perdido no deserto do Saara encontra um pequeno príncipe que viaja de planeta em planeta. Através de suas conversas, o príncipe compartilha lições sobre amor, amizade e a essência da vida.', 0),
(13, 'INF003', 'S', 'Onde Vivem os Monstros', '1963', 6, 'Maurice Sendak', 'Cosac Naify', 45.00, 10.00, 10.00, 4, 100, 10, '2003-06-25 03:00:00', 'Max, um menino travesso, é mandado para o quarto sem jantar e imagina uma terra onde monstros selvagens o coroam como rei. A história explora a imaginação e as emoções das crianças.', 0),
(14, 'INF004', 'N', 'Matilda', '1988', 6, 'Roald Dahl', 'Martins Fontes', 52.00, 10.00, 15.00, 6, 90, 10, '2023-10-01 03:00:00', 'Matilda é uma menina inteligente e apaixonada por livros, mas seus pais e a diretora da escola não a entendem. Com poderes telecinéticos, ela decide mudar sua vida e ajudar aqueles que ama.', 0),
(15, 'INF005', 'N', 'Reinações de Narizinho', '1931', 6, 'Monteiro Lobato', 'Globo', 47.90, 5.00, 10.00, 4, 0, 10, '2023-10-01 03:00:00', 'As aventuras de Narizinho, Pedrinho e a boneca Emília no Sítio do Picapau Amarelo, onde encontram personagens mágicos como o Visconde de Sabugosa e a Cuca.', 0),
(93, 'AUT009', 'S', 'A Arte da Guerra', 'Século V a', 7, 'Sun Tzu', 'Jardim dos Livros', 39.90, 10.00, 15.00, 4, 100, 10, '2023-10-01 03:00:00', 'Um tratado militar clássico que explora estratégias de guerra e liderança, aplicáveis também aos negócios e à vida pessoal.', 0),
(17, 'INF007', 'N', 'Peter Pan', '1911', 6, 'J.M. Barrie', 'Zahar', 54.90, 5.00, 10.00, 6, 100, 10, '2023-10-01 03:00:00', 'Peter Pan leva Wendy e seus irmãos para a Terra do Nunca, onde vivem aventuras com os Meninos Perdidos, o Capitão Gancho e a fada Sininho.', 0),
(18, 'INF008', 'N', 'O Menino Maluquinho', '1980', 6, 'Ziraldo', 'Melhoramentos', 39.90, 10.00, 15.00, 4, 150, 10, '2023-10-01 03:00:00', 'As travessuras e aventuras de um menino cheio de imaginação, que vive em um mundo de brincadeiras e descobertas.', 0),
(19, 'INF009', 'N', 'O Pequeno Nicolau', '1959', 6, 'René Goscinny', 'Martins Fontes', 44.90, 14.00, 10.00, 6, 90, 10, '2007-01-11 03:00:00', 'As histórias engraçadas e divertidas de Nicolau, um menino que vive situações cotidianas com seus amigos e família.', 0),
(20, 'INF010', 'S', 'A Bolsa Amarela', '1976', 6, 'Lygia Bojunga', 'Casa Lygia Bojunga', 49.90, 10.00, 15.00, 6, 80, 10, '2023-10-01 03:00:00', 'Raquel, uma menina cheia de sonhos e segredos, guarda suas vontades em uma bolsa amarela. A obra aborda temas como crescimento e identidade.', 0),
(21, 'TER001', 'S', 'It: A Coisa', '1986', 4, 'Stephen King', 'Suma', 99.90, 19.00, 15.00, 12, 60, 10, '2018-07-11 03:00:00', 'Em Derry, um grupo de crianças enfrenta um ser maligno que se alimenta de seus medos e assume a forma de seus piores pesadelos, incluindo o icônico palhaço Pennywise. Anos depois, eles retornam para enfrentar o mal novamente.', 0),
(22, 'TER002', 'N', 'O Exorcista', '1971', 4, 'William Peter Blatty', 'Alfaguara', 69.90, 5.00, 10.00, 6, 70, 10, '2023-10-01 03:00:00', 'Uma menina é possuída por uma entidade demoníaca, e dois padres são chamados para realizar um exorcismo. A obra é um clássico do terror sobrenatural.', 0),
(92, 'FAN010', 'N', 'O Maravilhoso Mágico de Oz', '1900', 3, 'L. Frank Baum', 'Zahar', 49.90, 10.00, 15.00, 6, 100, 10, '2023-10-01 03:00:00', 'Dorothy e seu cachorro Totó são levados por um furacão para a terra de Oz, onde embarcam em uma jornada para encontrar o Mágico de Oz e realizar seus desejos.', 0),
(24, 'TER004', 'N', 'O Iluminado', '1977', 4, 'Stephen King', 'Suma', 79.90, 49.00, 10.00, 6, 90, 10, '2020-03-14 03:00:00', 'Jack Torrance aceita um emprego como zelador de um hotel isolado durante o inverno. Logo, ele e sua família são assombrados por forças sobrenaturais.', 0),
(91, 'TER010', 'N', 'O Médico e o Monstro', '1886', 4, 'Robert Louis Stevenson', 'Penguin', 49.90, 25.00, 15.00, 6, 100, 10, '2022-02-01 03:00:00', 'Dr. Jekyll cria uma poção que transforma ele em Mr. Hyde, sua personalidade maligna. A obra explora a dualidade humana.', 0),
(26, 'TER006', 'N', 'O Chamado de Cthulhu', '1928', 4, 'H.P. Lovecraft', 'Martin Claret', 44.90, 10.00, 15.00, 6, 0, 10, '2023-10-01 03:00:00', 'Um investigador descobre a existência de um culto que adora Cthulhu, uma entidade cósmica que habita nas profundezas do oceano.', 0),
(27, 'TER007', 'S', 'O Bebê de Rosemary', '1967', 4, 'Ira Levin', 'Record', 59.90, 27.00, 10.00, 6, 80, 10, '2009-05-07 03:00:00', 'Rosemary Woodhouse suspeita que seus vizinhos estão envolvidos em um pacto satânico e que seu bebê pode ser parte de um plano maligno.', 0),
(29, 'TER009', 'S', 'O Silêncio dos Inocentes', '1988', 4, 'Thomas Harris', 'Record', 69.90, 10.00, 15.00, 6, 70, 10, '2023-10-01 03:00:00', 'A agente do FBI Clarice Starling busca a ajuda do Dr. Hannibal Lecter, um canibal e psiquiatra, para capturar um serial killer.', 0),
(90, 'TER008', 'N', 'O Corvo', '1845', 4, 'Edgar Allan Poe', 'Martin Claret', 39.90, 10.00, 15.00, 4, 90, 10, '2023-10-01 03:00:00', 'Um poema narrativo que conta a história de um homem que é visitado por um corvo falante após a morte de sua amada.', 0),
(31, 'FAN001', 'S', 'O Senhor dos Anéis: A Sociedade do Anel', '1954', 3, 'J.R.R. Tolkien', 'Martins Fontes', 89.90, 10.00, 15.00, 12, 50, 10, '2023-10-01 03:00:00', 'Frodo Bolseiro recebe a missão de destruir o Um Anel, uma poderosa e maligna joia criada pelo Senhor do Escuro Sauron. Ele parte em uma jornada épica com a Sociedade do Anel, composta por hobbits, humanos, elfos e anões, para salvar a Terra-média.', 0),
(32, 'FAN002', 'N', 'Harry Potter e a Pedra Filosofal', '1997', 3, 'J.K. Rowling', 'Rocco', 59.90, 5.00, 10.00, 6, 200, 10, '2023-10-01 03:00:00', 'Harry Potter descobre que é um bruxo e começa sua jornada na Escola de Magia e Bruxaria de Hogwarts. Lá, ele faz amigos, aprende magia e descobre segredos sobre seu passado, incluindo a existência da Pedra Filosofal.', 0),
(33, 'FAN003', 'N', 'As Crônicas de Nárnia: O Leão, a Feiticeira e o Guarda-Roupa', '1950', 3, 'C.S. Lewis', 'Martins Fontes', 49.90, 10.00, 15.00, 6, 150, 10, '2023-10-01 03:00:00', 'Quatro irmãos entram em um mundo mágico através de um guarda-roupa e ajudam o leão Aslan a derrotar a Feiticeira Branca, que congelou Nárnia em um inverno eterno.', 0),
(34, 'FAN004', 'N', 'O Hobbit', '1937', 3, 'J.R.R. Tolkien', 'Martins Fontes', 69.90, 41.00, 10.00, 8, 100, 10, '2012-07-26 03:00:00', 'Bilbo Bolseiro é recrutado por um grupo de anões para ajudá-los a recuperar seu tesouro roubado pelo dragão Smaug. Durante a jornada, ele encontra o Um Anel e o misterioso Gollum.', 0),
(35, 'FAN005', 'N', 'A Guerra dos Tronos', '1996', 3, 'George R.R. Martin', 'LeYa', 79.90, 10.00, 15.00, 10, 80, 10, '2022-02-10 03:00:00', 'Em Westeros, famílias nobres lutam pelo controle do Trono de Ferro. A trama é repleta de intrigas políticas, traições e batalhas épicas, enquanto uma ameaça antiga se aproxima no Norte.', 0),
(36, 'FAN006', 'N', 'O Nome do Vento', '2007', 3, 'Patrick Rothfuss', 'Arqueiro', 89.90, 10.00, 15.00, 12, 70, 10, '2023-10-01 03:00:00', 'Kvothe, um homem lendário, conta sua história de vida, desde sua infância em uma trupe de artistas até seus anos na Universidade, onde aprendeu magia e se envolveu em mistérios perigosos.', 0),
(37, 'FAN007', 'N', 'Coraline', '2002', 3, 'Neil Gaiman', 'Intrínseca', 54.90, 5.00, 10.00, 6, 0, 10, '2023-10-01 03:00:00', 'Coraline descobre uma porta secreta em sua casa que leva a um mundo paralelo, onde tudo parece perfeito, mas esconde segredos sombrios e perigosos.', 0),
(38, 'FAN008', 'S', 'A Roda do Tempo: O Olho do Mundo', '1990', 3, 'Robert Jordan', 'Intrínseca', 79.90, 8.00, 15.00, 10, 60, 10, '2018-06-20 03:00:00', 'Rand alThor e seus amigos são levados em uma jornada épica para salvar o mundo das forças do Escuro, enquanto descobrem seus próprios destinos como parte de uma profecia antiga.', 0),
(39, 'FAN009', 'N', 'Percy Jackson e o Ladrão de Raios', '2005', 3, 'Rick Riordan', 'Intrínseca', 59.90, 22.00, 10.00, 6, 120, 10, '2006-11-08 03:00:00', 'Percy Jackson descobre que é um semideus, filho de Poseidon, e embarca em uma missão para recuperar o raio de Zeus, roubado por um ladrão desconhecido.', 0),
(89, 'TER005', 'N', 'Frankenstein', '1818', 4, 'Mary Shelley', 'Martin Claret', 49.90, 10.00, 15.00, 4, 100, 10, '2023-10-01 03:00:00', 'Victor Frankenstein cria uma criatura em um experimento científico, mas foge horrorizado com o resultado. A criatura, rejeitada, busca vingança.', 0),
(41, 'AUT001', 'S', 'Eu Sou Malala', '2013', 7, 'Malala Yousafzai', 'Companhia das Letras', 69.90, 8.00, 15.00, 6, 70, 10, '2010-09-28 03:00:00', 'Malala Yousafzai, a mais jovem ganhadora do Prêmio Nobel da Paz, conta sua história de luta pelo direito à educação das meninas no Paquistão, mesmo após sobreviver a um atentado do Talibã.', 0),
(42, 'AUT002', 'N', 'Minha História', '2018', 7, 'Michelle Obama', 'Objetiva', 89.90, 5.00, 10.00, 8, 90, 10, '2023-10-01 03:00:00', 'A ex-primeira-dama dos EUA compartilha sua trajetória de vida, desde sua infância em Chicago até seus anos na Casa Branca, destacando suas lutas, conquistas e visão sobre o mundo.', 0),
(43, 'AUT003', 'N', 'A Autobiografia de Malcolm X', '1965', 7, 'Malcolm X', 'Record', 59.90, 23.00, 15.00, 6, 60, 10, '2017-08-20 03:00:00', 'Malcolm X narra sua transformação de criminoso para um dos maiores líderes do movimento pelos direitos civis, destacando sua luta contra o racismo e a busca por justiça.', 0),
(44, 'AUT004', 'N', 'Longa Caminhada até a Liberdade', '1994', 7, 'Nelson Mandela', 'Nova Fronteira', 79.90, 46.00, 10.00, 8, 80, 10, '2014-08-03 03:00:00', 'Nelson Mandela conta sua jornada de luta contra o apartheid na África do Sul, seus 27 anos de prisão e sua ascensão à presidência, tornando-se um símbolo de resistência e reconciliação.', 0),
(45, 'AUT005', 'S', 'Steve Jobs', '2011', 7, 'Walter Isaacson', 'Companhia das Letras', 99.90, 10.00, 15.00, 12, 100, 10, '2023-10-01 03:00:00', 'A biografia autorizada de Steve Jobs, cofundador da Apple, revela sua vida pessoal, sua visão revolucionária e seu impacto na tecnologia e na cultura moderna.', 0),
(46, 'AUT006', 'N', 'A Menina que Roubava Livros', '2005', 7, 'Markus Zusak', 'Intrínseca', 69.90, 10.00, 15.00, 6, 0, 10, '2023-10-01 03:00:00', 'Na Alemanha nazista, Liesel Meminger encontra refúgio nos livros que rouba, enquanto a Morte narra sua história de sobrevivência e esperança durante a Segunda Guerra Mundial.', 0),
(47, 'AUT007', 'N', 'Educated', '2018', 7, 'Tara Westover', 'Rocco', 79.90, 5.00, 10.00, 8, 70, 10, '2023-10-01 03:00:00', 'Tara Westover cresceu em uma família mórmon isolada e sem acesso à educação formal. Aos 17 anos, ela começou a estudar por conta própria e acabou se formando em Harvard.', 0),
(48, 'AUT008', 'S', 'A Vida em Disparate', '2016', 7, 'Rafinha Bastos', 'Sextante', 49.90, 34.00, 15.00, 6, 80, 10, '2024-07-09 03:00:00', 'O humorista Rafinha Bastos conta sua trajetória de vida, desde sua infância até o sucesso na televisão, com histórias engraçadas e reflexões sobre a carreira.', 0),
(88, 'TER003', 'N', 'Drácula', '1897', 4, 'Bram Stoker', 'Penguin', 59.90, 10.00, 15.00, 8, 80, 10, '2023-10-01 03:00:00', 'O conde Drácula, um vampiro imortal, viaja da Transilvânia para a Inglaterra, onde espalha o terror. Jonathan Harker e Van Helsing tentam detê-lo.', 0),
(50, 'AUT010', 'N', 'A Cabana', '2007', 7, 'William P. Young', 'Arqueiro', 59.90, 10.00, 15.00, 6, 90, 10, '2023-10-01 03:00:00', 'Mack Phillips, um homem em luto, recebe um convite misterioso para encontrar Deus em uma cabana isolada, onde confronta suas dúvidas e encontra redenção.', 0),
(72, 'SUS004', 'N', 'Misery', '1987', 5, 'Stephen King', 'Suma', 69.90, 5.00, 10.00, 6, 70, 10, '2023-10-01 03:00:00', 'Paul Sheldon, um escritor famoso, é resgatado por uma fã obsessiva após um acidente de carro. Ele logo descobre que está preso em um pesadelo.', 0),
(52, 'SUS002', 'N', 'Garota Exemplar', '2012', 5, 'Gillian Flynn', 'Intrínseca', 59.90, 5.00, 10.00, 6, 90, 10, '2023-10-01 03:00:00', 'Amy Dunne desaparece no dia de seu aniversário de casamento, e seu marido Nick se torna o principal suspeito. A história é cheia de segredos e manipulações.', 0),
(53, 'SUS003', 'N', 'O Código Da Vinci', '2003', 5, 'Dan Brown', 'Arqueiro', 79.90, 56.00, 15.00, 8, 100, 10, '2021-04-30 03:00:00', 'Robert Langdon e Sophie Neveu desvendam códigos e segredos históricos para resolver um assassinato e descobrir um segredo que pode abalar a Igreja Católica.', 0),
(71, 'SUS001', 'N', 'E Não Sobrou Nenhum', '1939', 5, 'Agatha Christie', 'Globo', 59.90, 10.00, 15.00, 6, 80, 10, '2023-10-01 03:00:00', 'Dez pessoas são convidadas para uma ilha isolada, onde começam a morrer uma a uma, seguindo uma misteriosa canção infantil. Um clássico do suspense de Agatha Christie.', 0),
(55, 'SUS005', 'N', 'Antes de Dormir', '2011', 5, 'S.J. Watson', 'Record', 59.90, 44.00, 15.00, 6, 90, 10, '2018-08-14 03:00:00', 'Christine acorda todos os dias sem memória do dia anterior. Ela tenta reconstruir sua vida com a ajuda de um diário, mas descobre que nem tudo é o que parece.', 0),
(56, 'SUS006', 'S', 'O Homem de Giz', '2018', 5, 'C.J. Tudor', 'Intrínseca', 69.90, 30.00, 15.00, 6, 0, 10, '2008-01-25 03:00:00', 'Em 1986, um grupo de crianças encontra um cadáver na floresta. Anos depois, os sobreviventes recebem mensagens misteriosas que os levam de volta ao passado.', 0),
(57, 'SUS007', 'N', 'A Garota no Trem', '2015', 5, 'Paula Hawkins', 'Record', 59.90, 5.00, 10.00, 6, 80, 10, '2023-10-01 03:00:00', 'Rachel, uma mulher com problemas de alcoolismo, testemunha algo chocante durante suas viagens de trem e se envolve em um mistério de desaparecimento.', 0),
(58, 'SUS008', 'S', 'O Psicopata Americano', '1991', 5, 'Bret Easton Ellis', 'Cia das Letras', 69.90, 28.00, 15.00, 6, 60, 10, '2015-08-30 03:00:00', 'Patrick Bateman, um executivo de Wall Street, leva uma vida dupla como serial killer. A obra é uma crítica ácida ao consumismo e à superficialidade.', 0),
(73, 'SUS009', 'N', 'Jantar Secreto', '2016', 5, 'Raphael Montes', 'Companhia das Letras', 49.90, 10.00, 15.00, 6, 90, 10, '2023-10-01 03:00:00', 'Clarice, uma jovem solitária, é sequestrada por um estudante de medicina obcecado. Ele a leva para um apartamento onde planeja realizar um jantar macabro com seus amigos.', 0),
(60, 'SUS010', 'N', 'O Colecionador de Ossos', '1997', 5, 'Jeffery Deaver', 'Arqueiro', 69.90, 10.00, 15.00, 6, 70, 10, '2023-10-01 03:00:00', 'Lincoln Rhyme, um detetive tetraplégico, e Amelia Sachs, uma policial, investigam um serial killer que deixa pistas macabras em suas cenas de crime.', 0),
(87, 'INF006', 'N', 'O Mágico de Oz', '1900', 6, 'L. Frank Baum', 'Zahar', 49.90, 37.00, 15.00, 6, 120, 10, '2007-05-22 03:00:00', 'Dorothy e seu cachorro Totó são levados por um furacão para a terra de Oz, onde embarcam em uma jornada para encontrar o Mágico de Oz e realizar seus desejos.', 0),
(96, 'FC010', 'S', 'A Máquina do Tempo', '1895', 2, 'H.G. Wells', 'Penguin', 49.90, 19.00, 15.00, 6, 100, 10, '2006-05-11 03:00:00', 'Um inventor cria uma máquina que o leva ao ano 802.701, onde encontra duas raças humanas: os pacíficos Eloi e os selvagens Morlocks. A obra é uma reflexão sobre a evolução e a divisão de classes.', 0),
(86, 'INF002', 'N', 'Alice no País das Maravilhas', '1865', 6, 'Lewis Carroll', 'Zahar', 49.90, 29.00, 15.00, 6, 150, 10, '2013-02-07 03:00:00', 'Alice cai em um buraco e entra em um mundo mágico, onde encontra criaturas excêntricas como o Chapeleiro Maluco, o Gato de Cheshire e a Rainha de Copas. A obra é uma jornada surreal e cheia de simbolismos.', 0),
(63, 'ROM003', 'S', 'A Culpa é das Estrelas', '2012', 1, 'John Green', 'Intrínseca', 69.90, 10.00, 15.00, 6, 150, 10, '2023-10-01 03:00:00', 'Hazel e Gus, dois adolescentes com câncer, se apaixonam e vivem uma história emocionante, cheia de amor, dor e esperança.', 0),
(64, 'ROM004', 'N', 'Cinquenta Tons de Cinza', '2011', 1, 'E.L. James', 'Intrínseca', 79.90, 30.00, 10.00, 8, 200, 10, '2023-12-13 03:00:00', 'Ana Steele se envolve em um relacionamento intenso e complexo com o misterioso Christian Grey, explorando temas como poder e desejo.', 0),
(65, 'ROM005', 'S', 'Como Eu Era Antes de Você', '2012', 1, 'Jojo Moyes', 'Intrínseca', 69.90, 10.00, 15.00, 6, 180, 10, '2023-10-01 03:00:00', 'Louisa Clark é contratada para cuidar de Will, um homem paralisado, e ambos descobrem o amor e o significado da vida.', 0),
(66, 'ROM006', 'N', 'A Seleção', '2012', 1, 'Kiera Cass', 'Seguinte', 59.90, 48.00, 15.00, 6, 0, 10, '2008-09-20 03:00:00', 'America Singer é escolhida para participar de uma competição para conquistar o coração do príncipe Maxon, mas seu coração já pertence a outro.', 0),
(67, 'ROM007', 'N', 'P.S.: Eu Te Amo', '2004', 1, 'Cecelia Ahern', 'Novo Conceito', 49.90, 10.00, 15.00, 6, 100, 10, '2023-10-01 03:00:00', 'Holly recebe cartas de seu falecido marido, Gerry, que a guiam em uma jornada de superação e redescoberta do amor.', 0),
(68, 'ROM008', 'N', 'Eleanor & Park', '2012', 1, 'Rainbow Rowell', 'Seguinte', 54.90, 28.00, 10.00, 6, 90, 10, '2006-09-12 03:00:00', 'Dois adolescentes solitários se conectam através da música e dos quadrinhos, vivendo um romance doce e intenso.', 0),
(69, 'ROM009', 'N', 'A Cinco Passos de Você', '2018', 1, 'Rachael Lippincott', 'Seguinte', 59.90, 10.00, 15.00, 6, 80, 10, '2023-10-01 03:00:00', 'Stella e Will, dois pacientes com fibrose cística, se apaixonam, mas precisam manter uma distância física para sobreviver.', 0),
(70, 'ROM010', 'N', 'O Diário de uma Paixão', '1996', 1, 'Nicholas Sparks', 'Arqueiro', 49.90, 10.00, 15.00, 6, 100, 10, '2023-10-01 03:00:00', 'Noah e Allie vivem um romance intenso durante o verão, mas são separados pela guerra e pelas diferenças sociais. Anos depois, eles se reencontram e reacendem o amor.', 0),
(95, 'ROM002', 'N', 'O Morro dos Ventos Uivantes', '1847', 1, 'Emily Brontë', 'Penguin', 59.90, 11.00, 10.00, 6, 100, 10, '2018-06-01 03:00:00', 'A história de amor e vingança entre Heathcliff e Catherine, que transcende a morte e destrói as vidas daqueles ao seu redor.', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `num_ped` varchar(20) NOT NULL,
  `status` varchar(35) NOT NULL,
  `data` date NOT NULL,
  `hora` varchar(8) NOT NULL,
  `valor` decimal(18,2) NOT NULL,
  `vencimento` date NOT NULL,
  `desconto` decimal(18,2) NOT NULL,
  `formapag` char(1) NOT NULL,
  `cartao` varchar(20) NOT NULL,
  `num_cartao` varchar(20) NOT NULL,
  `venc_cartao` varchar(4) NOT NULL,
  `nome_cartao` varchar(40) NOT NULL,
  `cod_cartao` varchar(4) NOT NULL,
  `parcelas` int(11) NOT NULL,
  `data_pag` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `id_cliente`, `num_ped`, `status`, `data`, `hora`, `valor`, `vencimento`, `desconto`, `formapag`, `cartao`, `num_cartao`, `venc_cartao`, `nome_cartao`, `cod_cartao`, `parcelas`, `data_pag`) VALUES
(22, 0, '22.012', 'Em andamento', '0000-00-00', '', 0.00, '0000-00-00', 0.00, '', '', '', '', '', '', 0, '0000-00-00'),
(23, 0, '23.153', 'Em andamento', '0000-00-00', '', 0.00, '0000-00-00', 0.00, '', '', '', '', '', '', 0, '0000-00-00'),
(24, 0, '24.160', 'Em andamento', '0000-00-00', '', 0.00, '0000-00-00', 0.00, '', '', '', '', '', '', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_estados`
--

CREATE TABLE `tb_estados` (
  `id` int(2) UNSIGNED ZEROFILL NOT NULL,
  `uf` varchar(2) NOT NULL DEFAULT '',
  `nome` varchar(20) NOT NULL DEFAULT '',
  `frete` float(9,2) DEFAULT NULL,
  `cepi` char(8) DEFAULT NULL,
  `cepf` char(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `tb_estados`
--

INSERT INTO `tb_estados` (`id`, `uf`, `nome`, `frete`, `cepi`, `cepf`) VALUES
(01, 'AC', 'Acre', 9.75, '69900000', '69999999'),
(02, 'AL', 'Alagoas', 7.70, '57000000', '57999999'),
(03, 'AM', 'Amazonas', 9.70, '69000000', '69899999'),
(04, 'AP', 'Amapá', 7.85, '68900000', '68999999'),
(05, 'BA', 'Bahia', 6.56, '40000000', '48999999'),
(06, 'CE', 'Ceará', 8.30, '60000000', '63999999'),
(07, 'DF', 'Distrito Federal', 7.50, '70000000', '73699999'),
(08, 'ES', 'Espírito Santo', 4.50, '29000000', '29999999'),
(09, 'GO', 'Goiás', 5.20, '72800000', '76799999'),
(10, 'MA', 'Maranhão', 7.20, '65000000', '65999999'),
(11, 'MG', 'Minas Gerais', 5.25, '78000000', '78899999'),
(12, 'MS', 'Mato Grosso do Sul', 5.18, '79000000', '79999999'),
(13, 'MT', 'Mato Grosso', 6.17, '30000000', '39999999'),
(14, 'PA', 'Pará', 7.78, '66000000', '68899999'),
(15, 'PB', 'Paraíba', 8.20, '58000000', '58999999'),
(16, 'PE', 'Pernambuco', 9.10, '50000000', '56999999'),
(17, 'PI', 'Piauí', 8.57, '64000000', '64999999'),
(18, 'PR', 'Paraná', 4.70, '80000000', '87999999'),
(19, 'RJ', 'Rio de Janeiro', 4.50, '20000000', '28999999'),
(20, 'RN', 'Rio Grande do Norte', 7.25, '59000000', '59999999'),
(21, 'RO', 'Rondônia', 8.25, '78900000', '78999999'),
(22, 'RR', 'Roraima', 7.89, '69300000', '69399999'),
(23, 'RS', 'Rio Grande do Sul', 5.12, '90000000', '99999999'),
(24, 'SC', 'Santa Catarina', 4.78, '88000000', '89999999'),
(25, 'SE', 'Sergipe', 7.90, '49000000', '49999999'),
(26, 'SP', 'São Paulo', 0.00, '01000000', '19999999'),
(27, 'TO', 'Tocantins', 8.20, '77000000', '77999999');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cadcli`
--
ALTER TABLE `cadcli`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cadesc`
--
ALTER TABLE `cadesc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`),
  ADD UNIQUE KEY `rg` (`rg`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `itens_do_pedido`
--
ALTER TABLE `itens_do_pedido`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `livros`
--
ALTER TABLE `livros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_livros_categorias` (`id_categoria`),
  ADD KEY `fk_livros_escritor` (`escritor_id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tb_estados`
--
ALTER TABLE `tb_estados`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cadcli`
--
ALTER TABLE `cadcli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de tabela `cadesc`
--
ALTER TABLE `cadesc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `itens_do_pedido`
--
ALTER TABLE `itens_do_pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT de tabela `livros`
--
ALTER TABLE `livros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `tb_estados`
--
ALTER TABLE `tb_estados`
  MODIFY `id` int(2) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
