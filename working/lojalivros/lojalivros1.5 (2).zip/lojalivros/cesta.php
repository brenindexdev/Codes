<?php
$titulo = "Loja de Livros - Cesta de Compras";

require_once('include/conexao.php');
include_once('includes/cabecalho_site.php');

// Inicializa a sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: include/login_cadastro.php");
    exit();
}

// Função para sanitizar entradas
function sanitize_input($data)
{
    return htmlspecialchars(strip_tags(trim($data)));
}

// Initialize variables
$produto = sanitize_input($_GET['produto'] ?? '');
$inserir = sanitize_input($_GET['inserir'] ?? '');
$qt = 1;

// Create new order if needed
if (!isset($_SESSION['num_ped']) && $inserir === 'S') {
    $sql = "SELECT id, status FROM pedidos ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($dbc, $sql);
    $last_order = mysqli_fetch_array($result);
    mysqli_free_result($result);

    $id = ($last_order['id'] ?? 0) + 1;
    $num_ped = $id . "." . date("H") . substr(date("i"), 0, 1);

    $sql = "INSERT INTO pedidos (num_ped, status) VALUES (?, 'Em andamento')";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, "s", $num_ped);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $_SESSION['num_ped'] = $num_ped;
    $_SESSION['id_ped'] = $id;
    $_SESSION['num_boleto'] = $id . date("H") . substr(date("i"), 0, 1);
    $_SESSION['status'] = 'Em andamento';
}

// Handle item deletion
if (isset($_GET['excluir']) && $_GET['excluir'] === 'S' && isset($_GET['id'])) {
    $sql = "DELETE FROM itens_do_pedido WHERE id = ? AND num_ped = ?";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, "is", $_GET['id'], $_SESSION['num_ped']);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

// Get product details
if ($produto) {
    $sql = "SELECT l.*, c.descricao
            FROM livros l 
            INNER JOIN categorias c ON l.id_categoria = c.id
            WHERE l.codigo = ?";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, "s", $produto);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $product = mysqli_fetch_array($result);
    mysqli_stmt_close($stmt);
}

// Add item to cart
if (isset($_SESSION['num_ped']) && $inserir === 'S' && !empty($produto)) {
    // Check for duplicate items
    $sql = "SELECT codigo FROM itens_do_pedido WHERE codigo = ? AND num_ped = ?";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $produto, $_SESSION['num_ped']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $item_duplicado = mysqli_num_rows($result);
    mysqli_stmt_close($stmt);

    if ($item_duplicado === 0 && isset($product)) {
        $sql = "INSERT INTO itens_do_pedido 
                (num_ped, codigo, nome, qt, preco, preco_boleto, desconto, desconto_boleto)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($dbc, $sql);
        $preco_boleto = $product['preco'] * (1 - $product['desconto_boleto'] / 100);
        mysqli_stmt_bind_param(
            $stmt,
            "sssidddd",
            $_SESSION['num_ped'],
            $product['codigo'],
            $product['nome'],
            $qt,
            $product['preco'],
            $preco_boleto,
            $product['desconto'],
            $product['desconto_boleto']
        );
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

// Update cart quantities
if (isset($_GET['atualiza']) && $_GET['atualiza'] === 'S') {
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'txt') === 0) {
            $id = $_POST['id' . substr($key, 3)] ?? null;
            $quantity = max(1, intval($value)); // Ensure minimum quantity of 1

            if ($id) {
                $sql = "UPDATE itens_do_pedido SET qt = ? WHERE id = ? AND num_ped = ?";
                $stmt = mysqli_prepare($dbc, $sql);
                mysqli_stmt_bind_param($stmt, "iis", $quantity, $id, $_SESSION['num_ped']);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
        }
    }
}

// Recupera os itens do carrinho
$cart_items = [];
if (isset($_SESSION['num_ped'])) {
    $sql = "SELECT *, (preco - (preco * desconto / 100)) AS preco_desconto 
            FROM itens_do_pedido 
            WHERE num_ped = ? 
            ORDER BY id";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, "s", $_SESSION['num_ped']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_array($result)) {
        $cart_items[] = $row;
    }
    mysqli_stmt_close($stmt);
    $_SESSION['total_itens'] = count($cart_items);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fancybox CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Fancybox JS -->
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <title><?= $titulo; ?></title>
    <style>
        :root {
            --primary-color: #621cd4;
            --primary-hover: #4a148c;
            --secondary-color: #7e3ce8;
            --background-color: #f8f9fa;
            --text-color: #2d3748;
            --text-muted: #718096;
            --border-color: rgb(208, 215, 223);
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            padding-top: 110px;
            /* Garante que o body ocupe toda a altura da tela */
        }

        .back-button {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .back-button i {
            color: var(--primary-color);
            font-size: 1.25rem;
        }

        .back-button:hover {
            transform: scale(1.05);
            background: var(--white);
        }

        .cart-container {
            padding-right: 100px;
            padding-left: 100px;
            flex: 1;
            /* Faz o conteúdo principal ocupar o espaço disponível */
        }

        .cart-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .cart-header h2 {
            font-size: 2.2rem;
            color: black;
            margin-bottom: 5px;
        }

        .cart-header h5 {
            font-size: 1rem;
            color: var(--text-muted);
        }

        .cart-table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .cart-table th,
        .cart-table td {
            padding: 15px;
            text-align: center;
            /* Centraliza todo o conteúdo da tabela */
        }

        .cart-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
        }

        .cart-table tr:nth-child(even) {
            background-color: var(--background-color);
        }

        .img-livro {
            width: 100px;
            /* Largura da imagem */
            height: auto;
            /* Altura automática para manter a proporção */
            border-radius: 8px;
            /* Bordas arredondadas */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            /* Sombra suave */
            transition: ease all 0.2s;
        }

        .img-livro:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }

        .d-flex.flex-column.align-items-center {
            text-align: center;
            /* Centraliza o texto */
        }

        .quantity-input {
            width: 60px;
            padding: 8px;
            border: 2px solid var(--border-color);
            border-radius: 5px;
            text-align: center;
        }

        .remove-item {
            color: #dc3545;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .remove-item:hover {
            color: rgb(156, 26, 39);
            transform: scale(1.05);
        }

        .cart-summary {
            padding: 20px;
            margin-top: 20px;
        }

        .cart-summary h4 {
            color: var(--primary-color);
        }

        .cart-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }

        .cart-button {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
            border: none;
            /* Remove bordas indesejadas */
            cursor: pointer;
        }

        .cart-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2);
        }

        .cart-button:active {
            transform: translateY(0);
        }

        .empty-cart h2 {
            color: black;
            margin-bottom: 10px;
        }

        .empty-cart p {
            color: var(--text-muted);
            margin-bottom: 20px;
        }

        .empty-cart {
            background-color: var(--background-color);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.2);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: black !important;
            margin-bottom: 20px;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .back-link,
        .cart-button {
            text-decoration: none !important;
            /* Remove o sublinhado */
            color: white;
            /* Mantém a cor roxa */
            transition: all 0.3s ease;
            /* Adiciona transição suave */
        }

        .cart-button:hover {
            color: white !important;
            /* Muda a cor no hover */
            transform: translateY(-3px);
            /* Efeito de levantar o botão */
        }

        .cart-button:active {
            transform: translateY(1px);
            /* Efeito de pressionar o botão */
        }

        .btn-att {
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
            padding: 0.7rem 0.7rem;
            background: transparent;
            border-radius: 8px;
            /* Para manter o estilo dos outros botões */
            transition: all 0.2s ease;
            cursor: pointer;
        }

        .btn-att:hover {
            background: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {

            .cart-table th,
            .cart-table td {
                padding: 10px;
            }

            .cart-buttons {
                flex-direction: column;
                align-items: stretch;
            }

            .cart-button {
                width: 100%;
                margin-bottom: 10px;
            }
        }

        @media (max-width: 480px) {
            .img-livro {
                width: 70px;
                /* Tamanho menor para dispositivos móveis */
            }
        }
    </style>
</head>

<body class="pb-5">
    <div class="back-button ml-4 mt-2" onclick="window.history.back()">
        <i class="fas fa-arrow-left"></i>
    </div>

    <div class="cart-container pb-4">
        <?php if (empty($cart_items)): ?>
            <div class="d-flex flex-column justify-content-center align-items-center my-5 py-5 empty-cart">
                <h2>Sua cesta de compras está vazia!</h2>
                <p>Volte à loja e adicione alguns livros incríveis à sua cesta.</p>
                <a href="index.php" class="cart-button">Explorar Livros</a>
            </div>
        <?php else: ?>
            <div class="cart-header">
                <h2>Meu Carrinho</h2>
                <h5>Pedido Nº: <strong><?= htmlspecialchars($_SESSION['num_ped']) ?></strong></h5>
            </div>

            <form method="post" action="cesta.php?atualiza=S" onsubmit="return validateForm()">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Ações</th>
                            <th>Preço Unitário</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $subtotal = 0;
                        foreach ($cart_items as $index => $item):
                            $total_item = $item['preco_desconto'] * $item['qt'];
                            $subtotal += $total_item;
                        ?>
                            <tr>
                                <td>
                                    <div class="d-flex flex-column align-items-center">
                                        <!-- Imagem do livro -->
                                        <?php
                                        $imagem_path = "produtos/" . htmlspecialchars($item['codigo']) . ".jpg";
                                        if (file_exists($imagem_path)) {
                                            echo '<a href="' . $imagem_path . '" data-fancybox="carrinho-gallery" data-caption="' . htmlspecialchars($item['nome']) . '">';
                                            echo '<img src="' . $imagem_path . '" alt="' . htmlspecialchars($item['nome']) . '" class="img-livro">';
                                            echo '</a>';
                                        } else {
                                            echo '<img src="img/sem-imagem.jpg" alt="Imagem não disponível" class="img-livro">';
                                        }
                                        ?>
                                        <span class="mt-2"><?= '<b>' . htmlspecialchars($item['nome']) . '</b>' ?></span>
                                    </div>
                                </td>
                                <td>
                                    <input type="number"
                                        name="txt<?= $index + 1 ?>"
                                        value="<?= $item['qt'] ?>"
                                        min="1"
                                        class="quantity-input">
                                    <input type="hidden"
                                        name="id<?= $index + 1 ?>"
                                        value="<?= $item['id'] ?>">
                                </td>
                                <td>
                                    <a href="cesta.php?id=<?= $item['id'] ?>&excluir=S"
                                        class="remove-item"
                                        onclick="return confirm('Tem certeza que deseja remover este item?')">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                                <td>R$ <?= number_format($item['preco_desconto'], 2, ',', '.') ?></td>
                                <td><strong>R$ <?= number_format($total_item, 2, ',', '.') ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="cart-summary">
                    <h4>Subtotal: R$ <?= number_format($subtotal, 2, ',', '.') ?></h4>
                    <p class="text-muted">* O valor total não inclui o frete, que será calculado no fechamento do pedido.</p>
                </div>

                <div class="cart-buttons">
                    <button type="submit" class="btn-att cart-button">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <a href="index.php" class="cart-button">Continuar as compras</a>
                    <a href="login_cadastro/login_cadastro.php" class="cart-button">
                        Concluir Pedido <i class="fas fa-check"></i>
                    </a>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script>
        function validateForm() {
            const quantityInputs = document.querySelectorAll('.quantity-input');
            for (const input of quantityInputs) {
                if (parseInt(input.value) < 1) {
                    alert('A quantidade não pode ser menor que 1');
                    input.focus();
                    return false;
                }
            }
            return true;
        }

        // Inicializar Fancybox
        Fancybox.bind("[data-fancybox]", {
            Thumbs: {
                autoStart: false, // Desativa miniaturas
            },
            Toolbar: {
                display: {
                    left: [], // Remove a barra de informações
                    middle: ["zoomIn", "zoomOut", "toggle1to1", "rotateCCW", "rotateCW"], // Botões de zoom e rotação
                    right: ["close"], // Mantém apenas o botão de fechar
                },
            },
        });
    </script>

</body>

</html>