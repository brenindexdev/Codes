<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

</head>

<body>
  <nav id="sidebarMenu" class="sidebar">
    <div class="sidebar-sticky">
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link <?= strpos($_SERVER['PHP_SELF'], 'livros_menu.php') !== false ? 'active' : ''; ?>"
            href="livros_menu.php">
            <i class="fas fa-book"></i>
            Seus Livros
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= strpos($_SERVER['PHP_SELF'], 'livros_cad.php') !== false ? 'active' : ''; ?>"
            href="livros_cad.php">
            <i class="fas fa-plus-circle"></i>
            Cadastrar Livro
          </a>
        </li>
      </ul>
    </div>
  </nav>
</body>

</html>