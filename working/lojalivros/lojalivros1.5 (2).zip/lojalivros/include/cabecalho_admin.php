<!doctype html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Painel de Administração da Loja de Livros">
  <meta name="author" content="Loja de Livros">
  <title>Painel de Administração - Loja de Livros</title>
  <!-- Bootstrap core CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <style>
    :root {
      --primary-color: #621cd4;
      --primary-hover: #4a148c;
      --secondary-color: #7e3ce8;
      --background-color: #f8f9fa;
      --border-color: #e2e8f0;
      --text-color: #2d3748;
      --text-muted: #718096;
      --white: #ffffff;
      --sidebar-width: 20%;
    }

    body {
      font-family: 'Inter', sans-serif;
      background-color: var(--background-color);
      margin: 0;
      padding: 0;
    }

    /* Navbar Styles */
    .admin-navbar {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      padding: 1rem;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand {
      color: var(--white);
      font-size: 1.25rem;
      font-weight: 600;
    }

    .navbar-brand:hover {
      color: var(--white);
    }

    .logout-btn {
      border-radius: 50px !important;
      padding: 0.5rem 1.25rem !important;
      font-weight: 500 !important;
      transition: all 0.3s ease !important;
      display: flex !important;
      align-items: center !important;
      gap: 0.5rem !important;
      cursor: pointer !important;
      background: var(--white) !important;
      border: none !important;
      color: var(--primary-color) !important;
      text-decoration: none !important;
    }

    .logout-btn:hover {
      background: rgba(255, 255, 255, 0.9) !important;
      color: var(--primary-color) !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1) !important;
    }

    .logout-btn i {
      font-size: 0.9em;
    }

    /* Sidebar Styles */
    .sidebar {
      width: var(--sidebar-width);
      background: var(--white);
      min-height: calc(100vh - 64px);
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      padding: 2rem 0;
      z-index: 100;
      position: fixed;
      padding-top: 90px;
      transition: transform 0.3s ease;
    }

    .sidebar.show {
      transform: translateX(0);
    }

    .sidebar-sticky {
      position: sticky;
      top: 2rem;
    }

    .nav-link {
      color: var(--text-color);
      padding: 0.75rem 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      transition: all 0.3s ease;
      border-left: 4px solid transparent;
    }

    .nav-link:hover {
      background: var(--background-color);
      color: var(--primary-color);
    }

    .nav-link.active {
      color: var(--primary-color);
      background: var(--background-color);
      border-left-color: var(--primary-color);
      font-weight: 600;
    }

    .nav-link i {
      font-size: 1.1rem;
      width: 24px;
      text-align: center;
    }

    /* Main Content Area */
    .main-content {
      max-width: 80%;
      margin-left: var(--sidebar-width);
      padding: 2rem;
    }

    /* Page Header */
    .page-header {
      background: var(--white);
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
      margin-bottom: 2rem;
    }

    .page-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--text-color);
      margin: 0;
    }

    /* Cards and Containers */
    .content-card {
      background: var(--white);
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
      padding: 1.5rem;
      padding: 20px;
      box-sizing: border-box;
      max-width: 100%;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      align-items: stretch;
    }

    /* Forms */
    .form-label {
      color: var(--text-color);
      font-weight: 500;
      margin-bottom: 0.5rem;
    }

    .form-control {
      border: 2px solid var(--border-color);
      border-radius: 8px;
      padding: 0.75rem;
      transition: all 0.3s ease;
    }

    .form-control:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(98, 28, 212, 0.1);
    }

    /* Buttons */
    .btn-primary {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2);
    }

    /* Overlay para dispositivos móveis */
    .overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 99;
    }

    .overlay.show {
      display: block;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }

      .main-content {
        margin-left: 0;
        max-width: 100%;
      }

      .toggle-sidebar {
        display: block;
      }
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="admin-navbar fixed-top">
    <div class="container-fluid d-flex justify-content-between align-items-center">
      <button id="toggleSidebar" class="btn d-md-none toggle-sidebar">
        <i class="fas fa-bars text-white"></i>
      </button>
      <a class="navbar-brand" href="#">
        <i class="fas fa-book-reader me-2"></i>
        Painel Administrativo
      </a>
      <a href="../index.php" class="logout-btn">
        <i class="fas fa-sign-out-alt me-2"></i>
        Sair
      </a>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <?php include_once('menu_admin.php'); ?>
      <!-- Main Content -->
      <main class="main-content">
        <!-- Conteúdo principal aqui -->
      </main>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const toggleSidebar = document.getElementById('toggleSidebar');
      const sidebar = document.getElementById('sidebarMenu');
      const overlay = document.createElement('div');
      overlay.classList.add('overlay');

      document.body.appendChild(overlay);

      toggleSidebar.addEventListener('click', function() {
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
      });

      overlay.addEventListener('click', function() {
        sidebar.classList.remove('show');
        overlay.classList.remove('show');
      });
    });
  </script>
</body>

</html>