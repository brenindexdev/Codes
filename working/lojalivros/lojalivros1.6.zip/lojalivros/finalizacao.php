<?php
session_start(); // Inicia a sessão
$titulo = "Finalização do Pedido";

require_once('include/conexao.php');
include_once('includes/cabecalho_site.php');

// Verifica se há um pedido finalizado na sessão
if (!isset($_SESSION['pedido_finalizado'])) {
    header("Location: index.php");
    exit();
}

// Recupera os dados do pedido finalizado
$pedido_id = $_SESSION['pedido_finalizado'];
$sql = "SELECT * FROM pedidos WHERE id = ?";
$stmt = mysqli_prepare($dbc, $sql);
mysqli_stmt_bind_param($stmt, "i", $pedido_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result || mysqli_num_rows($result) === 0) {
    header("Location: index.php");
    exit();
}

$pedido = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Limpa a sessão após exibir os dados
unset($_SESSION['pedido_finalizado']);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo); ?></title>
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="css/styles.css"> <!-- Arquivo CSS externo -->
</head>

<body>
    <div class="container my-4">
        <h1 class="text-center mb-4">Pedido Finalizado</h1>
        <div class="card p-4">
            <h2>Detalhes do Pedido</h2>
            <p><strong>Número do Pedido:</strong> <?= htmlspecialchars($pedido['num_ped']); ?></p>
            <p><strong>Data:</strong> <?= htmlspecialchars($pedido['data_pedido']); ?></p>
            <p><strong>Hora:</strong> <?= htmlspecialchars($pedido['hora_pedido']); ?></p>
            <p><strong>Subtotal:</strong> R$ <?= number_format($pedido['subtotal'], 2, ',', '.'); ?></p>
            <p><strong>Desconto:</strong> R$ <?= number_format($pedido['desconto'], 2, ',', '.'); ?></p>
            <p><strong>Total:</strong> R$ <?= number_format($pedido['subtotal'] - $pedido['desconto'], 2, ',', '.'); ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($pedido['status']); ?></p>
        </div>
        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-primary">Voltar à Loja</a>
        </div>
    </div>

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>

</html>
<?php include_once('includes/rodape.php'); ?>