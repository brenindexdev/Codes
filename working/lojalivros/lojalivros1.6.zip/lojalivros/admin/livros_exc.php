<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'escritor') {
    header('Location: ../login_cadastro.php');
    exit;
}

require_once('../include/conexao.php');

// Verifica se a exclusão foi solicitada
if (isset($_GET['excluir']) && $_GET['excluir'] === 'S' && isset($_GET['id'])) {
    $livro_id = mysqli_real_escape_string($dbc, $_GET['id']);
    $escritor_id = $_SESSION['usuario_id'];

    // Verifica se o livro pertence ao escritor logado
    $query_verifica = "SELECT id FROM livros WHERE id = '$livro_id' AND escritor_id = '$escritor_id'";
    $result_verifica = mysqli_query($dbc, $query_verifica);

    if (mysqli_num_rows($result_verifica) > 0) {
        // Exclui o livro do banco de dados
        $query_excluir = "DELETE FROM livros WHERE id = '$livro_id'";
        if (mysqli_query($dbc, $query_excluir)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir livro: ' . mysqli_error($dbc)]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Você não tem permissão para excluir este livro.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Requisição inválida.']);
}
