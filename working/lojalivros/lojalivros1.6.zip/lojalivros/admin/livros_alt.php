<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'escritor') {
    header('Location: ../login_cadastro.php');
    exit;
}

include_once('../include/cabecalho_admin.php');
include_once('../include/menu_admin.php');
require_once('../include/conexao.php');

$id = isset($_GET['id']) ? $_GET['id'] : 0;
$escritor_id = $_SESSION['usuario_id'];

// Verifica se o livro pertence ao escritor
$query = "SELECT * FROM livros WHERE id = '$id' AND escritor_id = '$escritor_id'";
$result = mysqli_query($dbc, $query);

if (mysqli_num_rows($result) === 0) {
    header('Location: livros_menu.php');
    exit;
}

$livro = mysqli_fetch_assoc($result);

// Busca as categorias
$query_categorias = "SELECT id, descricao FROM categorias";
$result_categorias = mysqli_query($dbc, $query_categorias);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Coleta os dados do formulário
    $codigo = mysqli_real_escape_string($dbc, trim($_POST['codigo']));
    $destaque = mysqli_real_escape_string($dbc, $_POST['destaque']);
    $nome = mysqli_real_escape_string($dbc, $_POST['nome']);
    $ano = mysqli_real_escape_string($dbc, $_POST['ano']);
    $id_categoria = mysqli_real_escape_string($dbc, $_POST['id_categoria']);
    $autor = mysqli_real_escape_string($dbc, $_POST['autor']);
    $editora = mysqli_real_escape_string($dbc, $_POST['editora']);
    $preco = mysqli_real_escape_string($dbc, $_POST['preco']);
    $desconto = mysqli_real_escape_string($dbc, $_POST['desconto']);
    $desconto_boleto = mysqli_real_escape_string($dbc, $_POST['desconto_boleto']);
    $max_parcelas = mysqli_real_escape_string($dbc, $_POST['max_parcelas']);
    $estoque = mysqli_real_escape_string($dbc, $_POST['estoque']);
    $min_estoque = mysqli_real_escape_string($dbc, $_POST['min_estoque']);
    $sinopse = mysqli_real_escape_string($dbc, $_POST['sinopse']);

    // Atualiza o livro
    $query = "UPDATE livros SET 
              codigo = '$codigo',
              destaque = '$destaque',
              nome = '$nome',
              ano = '$ano',
              id_categoria = '$id_categoria',
              autor = '$autor',
              editora = '$editora',
              preco = '$preco',
              desconto = '$desconto',
              desconto_boleto = '$desconto_boleto',
              max_parcelas = '$max_parcelas',
              estoque = '$estoque',
              min_estoque = '$min_estoque',
              sinopse = '$sinopse'
              WHERE id = '$id' AND escritor_id = '$escritor_id'";

    if (mysqli_query($dbc, $query)) {
        echo "<script>
                Swal.fire({
                    title: 'Sucesso!',
                    text: 'Livro atualizado com sucesso!',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'livros_menu.php';
                    }
                });
              </script>";
    } else {
        echo "<script>
                Swal.fire({
                    title: 'Erro!',
                    text: 'Erro ao atualizar livro: " . mysqli_error($dbc) . "',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
              </script>";
    }
}
?>

<main class="main-content mt-5">
    <div class="page-header">
        <h1 class="page-title">Alterar Livro</h1>
    </div>

    <div class="content-card">
        <form method="POST" class="row g-3">
            <!-- Código do Livro -->
            <div class="col-md-4">
                <label for="codigo" class="form-label">Código do Livro</label>
                <input type="text" class="form-control" id="codigo" name="codigo"
                    value="<?= $livro['codigo'] ?>" required>
            </div>

            <!-- Destaque -->
            <div class="col-md-4">
                <label for="destaque" class="form-label">Destaque</label>
                <select class="form-select" id="destaque" name="destaque" required>
                    <option value="S" <?= $livro['destaque'] === 'S' ? 'selected' : '' ?>>Sim</option>
                    <option value="N" <?= $livro['destaque'] === 'N' ? 'selected' : '' ?>>Não</option>
                </select>
            </div>

            <!-- Nome do Livro -->
            <div class="col-md-4">
                <label for="nome" class="form-label">Nome do Livro</label>
                <input type="text" class="form-control" id="nome" name="nome"
                    value="<?= $livro['nome'] ?>" required>
            </div>

            <!-- Ano de Publicação -->
            <div class="col-md-4">
                <label for="ano" class="form-label">Ano de Publicação</label>
                <input type="number" class="form-control" id="ano" name="ano"
                    value="<?= $livro['ano'] ?>" min="1900" max="<?= date('Y'); ?>" required>
            </div>

            <!-- Categoria -->
            <div class="col-md-4">
                <label for="id_categoria" class="form-label">Categoria</label>
                <select class="form-select" id="id_categoria" name="id_categoria" required>
                    <?php while ($categoria = mysqli_fetch_assoc($result_categorias)): ?>
                        <option value="<?= $categoria['id'] ?>"
                            <?= $livro['id_categoria'] == $categoria['id'] ? 'selected' : '' ?>>
                            <?= $categoria['descricao'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <!-- Autor -->
            <div class="col-md-4">
                <label for="autor" class="form-label">Autor</label>
                <input type="text" class="form-control" id="autor" name="autor"
                    value="<?= $livro['autor'] ?>" required>
            </div>

            <!-- Editora -->
            <div class="col-md-4">
                <label for="editora" class="form-label">Editora</label>
                <input type="text" class="form-control" id="editora" name="editora"
                    value="<?= $livro['editora'] ?>" required>
            </div>

            <!-- Preço -->
            <div class="col-md-4">
                <label for="preco" class="form-label">Preço</label>
                <input type="number" step="0.01" class="form-control" id="preco" name="preco"
                    value="<?= $livro['preco'] ?>" required>
            </div>

            <!-- Desconto -->
            <div class="col-md-4">
                <label for="desconto" class="form-label">Desconto (%)</label>
                <input type="number" step="0.01" class="form-control" id="desconto" name="desconto"
                    value="<?= $livro['desconto'] ?>">
            </div>

            <!-- Desconto no Boleto -->
            <div class="col-md-4">
                <label for="desconto_boleto" class="form-label">Desconto no Boleto (%)</label>
                <input type="number" step="0.01" class="form-control" id="desconto_boleto"
                    name="desconto_boleto" value="<?= $livro['desconto_boleto'] ?>">
            </div>

            <!-- Máximo de Parcelas -->
            <div class="col-md-4">
                <label for="max_parcelas" class="form-label">Máximo de Parcelas</label>
                <input type="number" class="form-control" id="max_parcelas" name="max_parcelas"
                    value="<?= $livro['max_parcelas'] ?>" required>
            </div>

            <!-- Estoque -->
            <div class="col-md-4">
                <label for="estoque" class="form-label">Estoque</label>
                <input type="number" class="form-control" id="estoque" name="estoque"
                    value="<?= $livro['estoque'] ?>" required>
            </div>

            <!-- Estoque Mínimo -->
            <div class="col-md-4">
                <label for="min_estoque" class="form-label">Estoque Mínimo</label>
                <input type="number" class="form-control" id="min_estoque" name="min_estoque"
                    value="<?= $livro['min_estoque'] ?>" required>
            </div>

            <!-- Sinopse -->
            <div class="col-12">
                <label for="sinopse" class="form-label">Sinopse</label>
                <textarea class="form-control" id="sinopse" name="sinopse" rows="5" required><?= $livro['sinopse'] ?></textarea>
            </div>

            <!-- Botões -->
            <div class="col-12">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="fas fa-save me-2"></i>
                    Salvar Alterações
                </button>
                <a href="livros_menu.php" class="btn btn-secondary">
                    <i class="fas fa-times me-2"></i>
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</main>

<?php include_once('../include/rodape_admin.php'); ?>