<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'escritor') {
    header('Location: ../login_cadastro.php');
    exit;
}

include_once('../include/cabecalho_admin.php');
include_once('../include/menu_admin.php');
require_once('../include/conexao.php');

// Busca os livros do escritor
$escritor_id = $_SESSION['usuario_id'];
$query = "SELECT l.*, c.descricao as categoria 
          FROM livros l 
          INNER JOIN categorias c ON l.id_categoria = c.id 
          WHERE l.escritor_id = '$escritor_id'
          ORDER BY l.nome ASC";
$result = mysqli_query($dbc, $query);
?>

<main class="main-content mt-5">
    <div class="page-header d-flex justify-content-between align-items-center">
        <h1 class="page-title">Seus Livros</h1>
        <a href="livros_cad.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>
            Adicionar Livro
        </a>
    </div>

    <div class="content-card">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Nome</th>
                            <th>Categoria</th>
                            <th>Preço</th>
                            <th>Estoque</th>
                            <th>Destaque</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($livro = mysqli_fetch_assoc($result)): ?>
                            <tr id="livro-<?= $livro['id'] ?>">
                                <td><?= $livro['codigo'] ?></td>
                                <td><?= $livro['nome'] ?></td>
                                <td><?= $livro['categoria'] ?></td>
                                <td>R$ <?= number_format($livro['preco'], 2, ',', '.') ?></td>
                                <td><?= $livro['estoque'] ?></td>
                                <td><?= $livro['destaque'] === 'S' ? 'Sim' : 'Não' ?></td>
                                <td>
                                    <a href="livros_alt.php?id=<?= $livro['id'] ?>"
                                        class="btn btn-sm btn-primary me-2">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="excluirLivro(<?= $livro['id'] ?>)"
                                        class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-books fa-3x text-muted mb-3"></i>
                <p class="text-muted">Você ainda não cadastrou nenhum livro.</p>
                <a href="livros_cad.php" class="btn btn-primary mt-3">
                    <i class="fas fa-plus me-2"></i>
                    Cadastrar seu primeiro livro
                </a>
            </div>
        <?php endif; ?>
    </div>
</main>

<script>
    function excluirLivro(id) {
        Swal.fire({
            title: 'Tem certeza?',
            text: "Você não poderá reverter isso!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sim, excluir!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                // Faz uma requisição AJAX para excluir o livro
                fetch(`livros_exc.php?id=${id}&excluir=S`, {
                        method: 'GET'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Remove a linha da tabela
                            document.getElementById(`livro-${id}`).remove();
                            Swal.fire({
                                title: 'Excluído!',
                                text: 'O livro foi excluído com sucesso.',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });
                        } else {
                            Swal.fire({
                                title: 'Erro!',
                                text: data.message || 'Erro ao excluir o livro.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            title: 'Erro!',
                            text: 'Erro ao excluir o livro.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    });
            }
        });
    }
</script>

<?php include_once('../include/rodape_admin.php'); ?>