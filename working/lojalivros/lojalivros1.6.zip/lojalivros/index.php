<?php
$titulo = "Loja de Livros";

include_once("includes/cabecalho_site.php");
require_once("include/conexao.php");

// Verifica se o usuário está logado
if (isset($_SESSION['usuario_id'])) {
    // Busca informações do usuário no banco de dados
    require_once("include/conexao.php");
    $usuario_id = $_SESSION['usuario_id'];
    $query = "SELECT email FROM cadcli WHERE id = '$usuario_id'";
    $result = mysqli_query($dbc, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $email = $row['email'];
    } else {
        $email = "Usuário não encontrado"; // Mensagem de fallback
    }
} else {
    $email = "Visitante"; // Mensagem para usuários não logados
}

// Ordena os destaques por preço com desconto
$ordenar = isset($_GET['ordenar']) ? $_GET['ordenar'] : "preco_desconto DESC";

// Seleciona as ofertas em destaque e ordena pelo preço com desconto
$q = "SELECT *, (preco - (preco * desconto / 100)) AS preco_desconto
      FROM livros
      WHERE destaque = 'S'
      ORDER BY " . $ordenar;
$r = @mysqli_query($dbc, $q);
$total_registros = mysqli_num_rows($r);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo; ?></title>

    <!-- Fancybox CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css" />
    <style>
        :root {
            --primary-color: #621cd4;
            --primary-hover: #4a148c;
            --secondary-color: #7e3ce8;
            --background-color: #f8f9fa;
            --border-color: #e2e8f0;
            --text-color: #2d3748;
            --text-muted: #718096;
            --success-color: #38a169;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            /* Garante que o body ocupe toda a altura da tela */
            margin: 0px !important;
            padding: 0px !important;
        }

        .conteudo {
            flex: 1;
            /* Faz o conteúdo principal ocupar o espaço disponível */
        }

        .category-menu {
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            margin-top: 1.5rem;
        }

        .hero-banner {
            position: relative;
            border-radius: 20px;
            overflow: hidden;
            margin-bottom: 3rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .hero-banner img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }

        .featured-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding: 1rem 0;
        }

        .featured-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-color);
        }

        .featured-count {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            margin-left: 1rem;
        }

        .sort-options {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .sort-link {
            text-decoration: none;
            color: var(--text-muted);
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.2s ease;
        }

        .sort-link:hover {
            background: var(--background-color);
            color: var(--primary-color);
        }

        .sort-active {
            background: var(--primary-color);
            color: white;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 2rem;
            padding: 1rem 0;
        }

        .product-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
        }

        .product-image {
            position: relative;
            padding: 1rem;
            background: var(--background-color);
            text-align: center;
        }

        .product-image img {
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }

        .product-image img:hover {
            transform: scale(1.05);
        }

        .zoom-icon {
            position: absolute;
            bottom: 1rem;
            right: 1rem;
            background: white;
            padding: 0.5rem;
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .zoom-icon img {
            width: 19px;
            height: 19px;
        }

        .zoom-icon:hover {
            transform: scale(1.1);
        }

        .product-info {
            padding: 1.5rem;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .product-name {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 0.5rem;
            min-height: 2.5rem;
            flex: 1;
        }

        .product-price {
            margin: 1rem 0;
        }

        .original-price {
            color: var(--text-muted);
            text-decoration: line-through;
            font-size: 0.9rem;
        }

        .discounted-price {
            color: var(--primary-color);
            font-size: 1.25rem;
            font-weight: 700;
            margin-top: 0.25rem;
        }

        .details-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            color: white !important;
            gap: 0.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .details-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2);
        }

        .out-of-stock {
            background: #FEE2E2;
            color: #DC2626;
            padding: 0.25rem 0.75rem;
            border-radius: 4px;
            font-size: 0.875rem;
            font-weight: 500;
            display: inline-block;
            margin-bottom: 0.5rem;
        }

        @media (max-width: 1200px) {
            .product-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 768px) {
            .product-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .featured-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .sort-options {
                justify-content: center;
                flex-wrap: wrap;
            }
        }

        @media (max-width: 480px) {
            .product-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <!-- Conteúdo principal -->
    <div class="container conteudo">
        <!-- Menu de Categorias -->
        <div class="category-menu">
            <?php include_once('includes/menu_categoria.php'); ?>
        </div>

        <!-- Hero Banner -->
        <div class="hero-banner">
            <img src="img/deco_home.png" alt="Decoração da Home Page" class="img-fluid">
        </div>

        <!-- Featured Section Header -->
        <div class="featured-header">
            <div class="d-flex align-items-center">
                <h2 class="featured-title">Destaques Gerais</h2>
                <span class="featured-count"><?= $total_registros ?> itens</span>
            </div>
            <div class="sort-options">
                Ordenar por:
                <?php if ($ordenar == "preco_desconto ASC"): ?>
                    <span class="sort-link sort-active">Menor preço</span>
                    <a href="index.php?ordenar=preco_desconto DESC" class="sort-link">Maior preço</a>
                <?php else: ?>
                    <a href="index.php?ordenar=preco_desconto ASC" class="sort-link">Menor preço</a>
                    <span class="sort-link sort-active">Maior preço</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Product Grid -->
        <div class="product-grid">
            <?php
            for ($contador = 0; $contador < $total_registros; $contador++) {
                $reg = @mysqli_fetch_array($r, MYSQLI_ASSOC);
                $codigo = $reg['codigo'];
                $nome = $reg['nome'];
                $estoque = $reg['estoque'];
                $min_estoque = $reg['min_estoque'];
                $preco = $reg['preco'];
                $desconto = $reg['desconto'];
                $valor_desconto = $preco - ($preco * $desconto / 100);
            ?>
                <div class="product-card">
                    <div class="product-image">
                        <!-- Link para a imagem com Fancybox -->
                        <a href="produtos/<?= $codigo ?>.jpg" data-fancybox="image-<?= $codigo ?>" data-caption="<?= $nome ?>">
                            <img src="produtos/<?= $codigo ?>.jpg" alt="<?= $nome ?>">
                        </a>
                        <!-- Ícone de zoom (sem data-fancybox) -->
                        <!-- <a href="#" class="zoom-icon" onclick="abrirFancybox('<?= $codigo ?>', '<?= $nome ?>')">
                                <img src="img/search.png" alt="Ampliar" width="20" height="20">
                            </a> -->
                    </div>
                    <div class="product-info">
                        <h3 class="product-name"><?= $nome ?></h3>

                        <?php if ($estoque < $min_estoque): ?>
                            <span class="out-of-stock">Indisponível</span>
                        <?php endif; ?>

                        <div class="product-price">
                            <div class="original-price">
                                De: R$ <?= number_format($preco, 2, ',', '.') ?>
                            </div>
                            <div class="discounted-price">
                                Por: R$ <?= number_format($valor_desconto, 2, ',', '.') ?>
                            </div>
                        </div>

                        <a href="detalhes.php?produto=<?= $codigo ?>" class="details-button">
                            <img src="img/info.svg" alt="" width="20" height="20">
                            Mais detalhes
                        </a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Fancybox JS -->
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <script>
        // Inicializar Fancybox
        Fancybox.bind("[data-fancybox]", {
            Thumbs: {
                autoStart: false, // Desativa miniaturas
            },
            Toolbar: {
                display: {
                    left: [], // Remove a barra de informações
                    middle: ["zoomIn", "zoomOut", "toggle1to1", "rotateCCW", "rotateCW"], // Botões de zoom e rotação
                    right: ["close"], // Mantém apenas o botão de fechar
                },
            },
        });

        // Função para abrir o Fancybox manualmente
        function abrirFancybox(codigo, nome) {
            Fancybox.show([{
                src: `produtos/${codigo}.jpg`,
                caption: nome,
            }, ]);
        }
    </script>
</body>

</html>
<?php include_once('includes/rodape.php'); ?>