<?php
session_start(); // Inicia a sessão
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="../../favicon.ico">

  <title><?php echo $titulo; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- SweetAlert2 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

  <!-- SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <!-- Font Awesome para ícones -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>

<style>
  :root {
    --primary-color: #621cd4;
    --primary-hover: #4a148c;
    --secondary-color: #7e3ce8;
    --background-color: #f8f9fa;
    --border-color: #e2e8f0;
    --text-color: #2d3748;
    --text-muted: #718096;
    --white: #ffffff;
  }

  /* Estilos personalizados para o SweetAlert2 */
  .swal2-popup {
    background: var(--background-color);
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    color: var(--text-color);
  }

  .swal2-title {
    color: var(--primary-color);
    font-size: 1.5rem;
    font-weight: 700;
  }

  .swal2-content {
    color: var(--text-muted);
    font-size: 1rem;
  }

  .swal2-confirm {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 0.75rem 1.5rem !important;
    font-size: 1rem !important;
    font-weight: 500 !important;
    transition: all 0.3s ease !important;
  }

  .swal2-confirm:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2) !important;
  }

  .swal2-cancel {
    background: var(--background-color) !important;
    border: 1px solid var(--border-color) !important;
    border-radius: 8px !important;
    padding: 0.75rem 1.5rem !important;
    font-size: 1rem !important;
    font-weight: 500 !important;
    color: var(--text-color) !important;
    transition: all 0.3s ease !important;
  }

  .swal2-cancel:hover {
    background: var(--background-color) !important;
    border-color: var(--primary-color) !important;
    color: var(--primary-color) !important;
  }

  #nav {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
  }

  .navbar-brand {
    margin-right: 2rem;
    padding: 0;
    transition: transform 0.3s ease;
  }

  .navbar-brand:hover {
    transform: scale(1.05);
  }

  .navbar-brand img {
    max-height: 75px;
    width: auto;
  }

  .navbar-toggler {
    border: 2px solid rgba(255, 255, 255, 0.8) !important;
    padding: 0.5rem !important;
    transition: all 0.3s ease !important;
  }

  .navbar-toggler:hover {
    background-color: rgba(255, 255, 255, 0.1) !important;
  }

  .navbar-toggler-icon {
    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255, 255, 255, 0.8)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E") !important;
  }

  .navbar-collapse {
    justify-content: flex-end !important;
  }

  .nav-item {
    margin: 0 0.5rem;
    display: flex;
    align-items: center;
  }

  .text-light {
    color: var(--white) !important;
    font-size: 0.95rem;
    letter-spacing: 0.02em;
  }

  .btn {
    border-radius: 50px !important;
    padding: 0.5rem 1.25rem !important;
    font-weight: 500 !important;
    transition: all 0.3s ease !important;
    display: flex !important;
    align-items: center !important;
    gap: 0.5rem !important;
    cursor: pointer !important;
  }

  .btn i {
    font-size: 0.9em !important;
  }

  .btn-light {
    background: var(--white) !important;
    border: none !important;
    color: var(--primary-color) !important;
  }

  .btn-light:hover {
    background: rgba(255, 255, 255, 0.9) !important;
    color: var(--primary-color) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1) !important;
  }

  .btn-outline-light {
    border: 2px solid var(--white) !important;
    color: var(--white) !important;
    padding: 11px !important;
    background: transparent !important;
  }

  .btn-outline-light:hover {
    background: var(--white) !important;
    color: var(--primary-color) !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1) !important;
  }

  @media (max-width: 767.98px) {
    .navbar-nav {
      padding: 1rem 0;
    }

    .nav-item {
      margin: 0.5rem 0;
    }

    .navbar-collapse {
      background: var(--primary-hover);
      margin: 0.5rem -1rem -0.75rem !important;
      padding: 1rem !important;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }
  }
</style>

<body>
  <!-- Fixed navbar -->
  <nav id="nav" class="navbar navbar-expand-md fixed-top">
    <!-- Logo à esquerda -->
    <a class="navbar-brand" href="index.php">
      <img src="img/logo4.png" alt="" width="120px">
    </a>

    <!-- Botão de toggle para mobile -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Conteúdo à direita -->
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <div class="navbar-nav ml-auto">
        <?php if (isset($_SESSION['usuario_id'])): ?>
          <?php
          require_once("include/conexao.php");
          $usuario_id = $_SESSION['usuario_id'];

          // Verifica se o usuário é um cliente (cadcli) ou um escritor (cadesc)
          if ($_SESSION['tipo_usuario'] === 'cliente') {
            $query = "SELECT nome, sobrenome FROM cadcli WHERE id = '$usuario_id'";
          } else {
            $query = "SELECT nome, sobrenome FROM cadesc WHERE id = '$usuario_id'";
          }

          $result = mysqli_query($dbc, $query);

          if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $nome = $row['nome'];
            $sobrenome = $row['sobrenome'];
          } else {
            // Caso o usuário não seja encontrado, define valores padrão
            $nome = "Usuário";
            $sobrenome = "";
          }
          ?>
          <span class="nav-item text-light m-1 mr-1 d-flex align-items-center">
            <i class="fa-solid fa-user mr-2"></i><?= 'Olá,&nbsp;<b>' . $nome . ' ' . $sobrenome . '!</b>'; ?>
          </span>
          <?php if (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'escritor'): ?>
            <div class="nav-item mx-1 my-2">
              <button class="btn btn-light" onclick="window.location.href='admin/livros_menu.php'">
                <i class="fa-solid fa-user-shield"></i> Adm
              </button>
            </div>
          <?php endif; ?>
          <div class="nav-item mx-1 my-2">
            <button class="btn btn-light" onclick="window.location.href='include/logout.php'">
              <i class="fa-solid fa-sign-out"></i> Sair
            </button>
          </div>
          <div class="nav-item mx-2 my-2">
            <button class="btn btn-outline-light" onclick="verificarLoginCarrinho(event)">
              <i class="fa-solid fa-cart-shopping"></i>
            </button>
          </div>
        <?php else: ?>
          <div class="nav-item mx-1 my-2">
            <button class="btn btn-light" onclick="window.location.href='include/login_cadastro.php'">
              <i class="fa-solid fa-sign-in"></i> Entrar
            </button>
          </div>
          <div class="nav-item mx-1 my-2">
            <button class="btn btn-outline-light" onclick="verificarLoginCarrinho(event)">
              <i class="fa-solid fa-cart-shopping"></i>
            </button>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </nav>

</body>

<script>
  function verificarLoginCarrinho(event) {
    event.preventDefault();

    <?php if (!isset($_SESSION['usuario_id'])): ?>
      Swal.fire({
        title: 'Você não está logado!',
        text: 'Crie uma conta ou entre para acessar seu carrinho.',
        icon: 'warning',
        confirmButtonText: 'Entrar',
        showCancelButton: true,
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = "include/login_cadastro.php";
        }
      });
    <?php else: ?>
      // Redireciona para a cesta com o parâmetro abrir_pedido
      window.location.href = "cesta.php?abrir_pedido=S";
    <?php endif; ?>
  }
</script>