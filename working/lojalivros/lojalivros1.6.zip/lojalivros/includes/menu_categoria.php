<?php
$cat = isset($_GET['cat_nome']) ? $_GET['cat_nome'] : 'Home';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        :root {
            --primary-color: #621cd4;
            --primary-hover: #4a148c;
            --secondary-color: #7e3ce8;
            --background-color: #f8f9fa;
            --border-color: #e2e8f0;
            --text-color: #2d3748;
            --text-muted: #718096;
        }

        .container {
            margin-top: 65px;
        }

        .category-tabs {
            background: whitesmoke !important;
            border-radius: 15px !important;
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.1) !important;
        }

        .category-tabs .nav-item {
            margin: 0 0.5rem !important;
        }

        .category-tabs .nav-link {
            color: var(--text-color) !important;
            font-weight: 500 !important;
            border-radius: 8px !important;
            transition: all 0.3s ease !important;
            border: none !important;
        }

        .category-tabs .nav-link:hover {
            color: var(--primary-color) !important;
            transform: translateY(-3px) !important;
        }

        .category-tabs .nav-link.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            color: white !important;
            box-shadow: 0 4px 12px rgba(98, 28, 212, 0.2) !important;
            transform: translateY(-3px) !important;
        }

        @media (max-width: 768px) {
            .category-tabs {
                flex-direction: column;
                align-items: left;
            }

            .category-tabs .nav-item {
                margin: 0.5rem 0;
            }

            .category-tabs .nav-link {
                width: 100%;
                text-align: left;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="col-12">
            <ul class="nav nav-tabs justify-content-center category-tabs">
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Home') echo "active"; ?>" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Ficção Científica') echo "active"; ?>"
                        href="categorias.php?cat_id=2&cat_nome=Ficção Científica&order=preco_desconto ASC">Ficção Científica</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Infantil') echo "active"; ?>"
                        href="categorias.php?cat_id=6&cat_nome=Infantil&order=preco_desconto ASC">Infantil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Terror') echo "active"; ?>"
                        href="categorias.php?cat_id=4&cat_nome=Terror&order=preco_desconto ASC">Terror</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Fantasia') echo "active"; ?>"
                        href="categorias.php?cat_id=3&cat_nome=Fantasia&order=preco_desconto ASC">Fantasia</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Autobiografia') echo "active"; ?>"
                        href="categorias.php?cat_id=7&cat_nome=Autobiografia&order=preco_desconto ASC">Autobiografia</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Suspense') echo "active"; ?>"
                        href="categorias.php?cat_id=5&cat_nome=Suspense&order=preco_desconto ASC">Suspense</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if ($cat == 'Romance') echo "active"; ?>"
                        href="categorias.php?cat_id=1&cat_nome=Romance&order=preco_desconto ASC">Romance</a>
                </li>
            </ul>
        </div>
    </div>
</body>

</html>