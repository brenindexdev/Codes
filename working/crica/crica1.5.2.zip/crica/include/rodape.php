<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Rodapé</title>
    <style>
        body {
            background-color: #072D17;
        }

        .footer {}

        span {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 10px;
            opacity: 75%;
            color: white;
            margin: 3px;
        }
    </style>
</head>

<body>
    <div class="footer d-flex flex-row min-vh-100 mx-3">
        <div class="col-md-4 col-sm-6 text-start">
            <span>© Todos os Direitos Reservados</span>
            <a href=""><span>Termos de Uso</span></a>
        </div>
        <div class="col-md-8 col-sm-6 text-end">
            <span>by:</span>
            <span>Aline M. de Almeida</span>
            <span>Breno S. Domingues</span>
            <span>Cassiano S. Biava</span>
            <span>Diogo S. de Melo</span>
            <span>Lucas Rogério dos S. Pereira</span>
        </div>
    </div>
    </div>

    <!-- Bootstrap JS e Font Awesome -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>