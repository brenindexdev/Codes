<?php
include_once("configuracao.php");

$conexao = new mysqli($host, $usuario, $senha, $database);

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conexao->query("DELETE FROM salas WHERE nome_sala='$id'");
}

header("Location: pesquisa_salas.php");
exit();
