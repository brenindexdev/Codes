<?php
include_once("configuracao.php");

// Verifica se o usuário está autenticado
if (!isset($_SESSION['Username']) || !isset($_SESSION['senha'])) {
    die("Erro: Usuário não autenticado. Faça login novamente.");
}

// Conexão com o banco de dados
$conexao = new mysqli($host, $_SESSION['Username'], $_SESSION['senha'], $database);

if ($conexao->connect_error) {
    die("Erro na conexão: " . $conexao->connect_error);
}

// Pesquisa de salas
$pesquisa = "";
if (isset($_POST['pesquisar'])) {
    $pesquisa = $_POST['nome_sala'];
}

// Consultar as salas no banco
$query = "SELECT * FROM salas WHERE nome_sala LIKE '%$pesquisa%' ORDER BY nome_sala";
$resultado = mysqli_query($conexao, $query);

// Excluir sala
if (isset($_GET['excluir_sala'])) {
    $codigo_sala = $_GET['excluir_sala'];
    $delete_query = "DELETE FROM salas WHERE codigo_sala = '$codigo_sala'";
    if (mysqli_query($conexao, $delete_query)) {
        header("Location: salas.php"); // Redireciona para a mesma página após exclusão
    } else {
        echo "Erro ao excluir a sala.";
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Salas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-custom {
            background-color: #0b4925;
            color: white;
        }

        .btn-custom:hover {
            background-color: #106936;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Formulário de Pesquisa -->
        <div class="form-container">
            <h2 class="text-center mb-4">Pesquisa de Salas</h2>
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="nome_sala" class="form-label">Nome da Sala</label>
                    <input type="text" class="form-control" id="nome_sala" name="nome_sala" value="<?php echo $pesquisa; ?>" placeholder="Digite o nome da sala">
                </div>
                <button type="submit" name="pesquisar" class="btn btn-custom">Pesquisar</button>
            </form>
        </div>

        <!-- Listagem de Salas -->
        <div class="form-container">
            <h2 class="text-center mb-4">Salas Disponíveis</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Código</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Capacidade</th>
                        <th scope="col">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($sala = mysqli_fetch_assoc($resultado)): ?>
                        <tr>
                            <td><?php echo $sala['codigo_sala']; ?></td>
                            <td><?php echo $sala['nome_sala']; ?></td>
                            <td><?php echo $sala['capacidade_sala']; ?></td>
                            <td>
                                <a href="editar_salas.php?codigo_sala=<?php echo $sala['nome_sala']; ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="deleta_salas.php?excluir_sala=<?php echo $sala['nome_sala']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>