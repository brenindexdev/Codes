<?php
session_start();

if (!isset($_SESSION['Username']) || !isset($_SESSION['senha'])) {
    die("Erro: Sessão inválida. Faça login novamente.");
}

$usuario = $_SESSION['Username'];
$senha = $_SESSION['senha'];
$database = 'crica';
$host = 'localhost';
