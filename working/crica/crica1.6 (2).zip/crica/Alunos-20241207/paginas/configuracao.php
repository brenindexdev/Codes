<?php 

  session_start();
  $usuario = $_SESSION['Username'];
  $senha = $_SESSION['senha'];
  $database = 'crica';
  $host = 'localhost';
?>