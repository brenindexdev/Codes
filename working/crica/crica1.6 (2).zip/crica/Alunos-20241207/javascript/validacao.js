function formatar_cpf(input) {

    var tamanho = input.value.length 

    if ( tamanho == 3 || tamanho == 7)
        input.value += '.'

    if (tamanho == 11)
        input.value += '-'

}

//-----------------------------
function formatar_telefone(input){
   
    // remove todos os caractes não numéridos
    var telefone = input.value.replace(/\D/g,'')

    // insere os paranteses e o traço
    telefone = telefone.replace(
        /(\d{2})(\d{5})(\d{4})/,'($1)$2-$3')

    input.value = telefone     

}