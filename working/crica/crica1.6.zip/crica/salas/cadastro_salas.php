<?php

include_once("configuracao.php");

// Verifica se o usuário está autenticado
if (!isset($_SESSION['Username']) || !isset($_SESSION['senha'])) {
    die("Erro: Usuário não autenticado. Faça login novamente.");
}

// Conexão com o banco de dados
$conexao = new mysqli($host, $_SESSION['Username'], $_SESSION['senha'], $database);

if ($conexao->connect_error) {
    die("Erro na conexão: " . $conexao->connect_error);
}

if (isset($_POST['salvar']) && !isset($_GET['codigo_sala'])) {
    $nome = $_POST['nome_sala'];
    $capacidade = $_POST['capacidade_sala'];

    $resultado = mysqli_query($conexao, "INSERT INTO salas (nome_sala, capacidade_sala) 
                VALUES ('$nome', '$capacidade')");

    if (!$resultado) {
        echo "Erro ao gravar no banco de dados.";
    }

    header("location: salas.php");
}

if (isset($_POST['salvar']) && isset($_GET['codigo_sala'])) {
    $id = $_GET['codigo_sala'];
    $nome = $_POST['nome_sala'];
    $capacidade = $_POST['capacidade_sala'];

    $resultado = mysqli_query($conexao, "UPDATE salas SET 
                nome_sala = '$nome', 
                capacidade_sala = '$capacidade' 
                WHERE codigo_sala = '$id'");

    if (!$resultado) {
        echo "Erro ao atualizar o banco de dados.";
    }

    header("location: salas.php");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Salas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-custom {

            background-color: #0b4925;
            color: white;
        }

        .btn-custom:hover {
            background-color: #053b1c;
            color: white;
        }

        .btn-custom:focus,
        .btn-custom:active {
            background-color: #106936 !important;
            color: white !important;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-container">
            <h2 class="text-center mb-4">Cadastro de Salas</h2>
            <form action="" method="POST">
                <!-- Nome da Sala -->
                <div class="mb-3">
                    <label for="nome_sala" class="form-label">Nome da Sala</label>
                    <input type="text" class="form-control" id="nome_sala" name="nome_sala" required
                        placeholder="Digite o nome da sala"
                        value="<?php if (isset($_GET['codigo_sala'])) echo $busca[1]; ?>">
                </div>
                <!-- Capacidade -->
                <div class="mb-3">
                    <label for="capacidade_sala" class="form-label">Capacidade</label>
                    <input type="number" class="form-control" id="capacidade_sala" name="capacidade_sala" required
                        placeholder="Digite a capacidade"
                        value="<?php if (isset($_GET['codigo_sala'])) echo $busca[2]; ?>">
                </div>
                <!-- Botões de ação -->
                <div class="row"></div>
                <div class="d-flex justify-content-start">
                    <button type="submit" name="salvar" class="btn btn-custom" onclick=""><i class=" fa-solid fa-floppy-disk"></i></button>
                </div>
                <div class="d-flex justify-content-end">
                    <a href="principal.php" class="btn btn-outline-secondary"><i class=" fa-solid fa-ban"></i></a>
                    <a href="pesquisa_salas.php" class="btn btn-custom"><i class=" fa-solid fa-search"></i></a>
                    <?php
                    if (isset($_GET['codigo_sala'])) {
                        echo "<a href='deleta_salas.php?codigo_sala=$_GET[codigo_sala]' class='btn btn-danger'>Excluir</a>";
                    }
                    ?>
                </div>
            </form>
        </div>
    </div>
</body>

</html>