<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <title>Crica</title>
</head>
<style>

</style>
<frameset rows="12%, 83%, 5%" frameborder="no">
    <!--Cabeçalho-->
    <frame src="include/cabecalho.php">

        <!--Conteúdo-->
        <frame src="include/login.php">

            <!--Rodapé-->
            <frame src="include/rodape.php">
</frameset>

</html>