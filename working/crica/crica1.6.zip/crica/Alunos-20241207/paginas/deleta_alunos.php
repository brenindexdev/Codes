<?php 

  include_once("configuracao.php");

  $conexao = new mysqli($host,$usuario,$senha,$database);

  $resultado = mysqli_query($conexao, "delete FROM alunos where prontuario_alu = '$_GET[prontuario]'" ) ;

  header("location: alunos.php");  
?>