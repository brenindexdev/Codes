<?php

if (
  isset($_POST['Username']) &&
  isset($_POST['Username'])
) {
  $usuario = $_POST['Username'];
  $senha = $_POST´['senha'];
  $database = 'crica';
  $host = 'localhost';

  $conexao = new mysqli(
    $host,
    $usuario,
    $senha,
    $database
  );

  if ($conexao->error)
    die("erro ao concectar no banco de dados" .
      $conexao->error);
  else {
    session_start();
    $_SESSION['Username'] = $usuario;
    $_SESSION['senha'] = $senha;

    header("location:./paginas/alunos.php");
  }
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Alunos</title>
</head>

<body>
  <center>
    <form action="" method="POST">
      <table>
        <tr>
          <td><label>Usuário:</label></td>
          <td>
            <input type="text" name="Username"
              required>
          </td>
        </tr>

        <tr>
          <td><label>Senha:</label></td>
          <td>
            <input type="password"
              name="senha"
              required>
          </td>
        </tr>

        <tr>
          <td colspan="2">
            <center>
              <button type="submit">Entrar
              </button>
            </center>
          </td>
        </tr>
      </table>
    </form>
  </center>
</body>

</html>