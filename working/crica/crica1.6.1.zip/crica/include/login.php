<?php
session_start(); // Inicia a sessão

require_once("../include/conexao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['Username'] ?? null;
    $senha = $_POST['senha'] ?? null;

    if (empty($usuario)) {
        $warningMessage = "Usuário requerido.";
    } elseif (empty($senha)) {
        $warningMessage = "Senha requerida.";
    } else {
        try {
            // Tenta conectar ao banco de dados
            $mysqli = new mysqli('localhost', $usuario, $senha, 'crica');

            if ($mysqli->connect_error) {
                throw new Exception("Usuário ou senha incorretos.");
            }

            // Login bem-sucedido, define as variáveis de sessão
            $_SESSION['Username'] = $usuario; // Armazena o nome de usuário na sessão
            $_SESSION['senha'] = $senha; // Armazena a senha na sessão

            // Redireciona para a página principal
            header('Location: ../principal.php');
            exit; // Não se esqueça de chamar exit após o redirecionamento
        } catch (Exception $e) {
            $warningMessage = $e->getMessage();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <title>Login | Crica</title>
</head>
<style>
    body {
        background-image: url('../img/bggrid.png');
    }

    .btn-custom,
    .btn-custom:hover {
        width: 100%;
        font-size: 15px;
        background-color: #0b4925;
        color: white;
    }

    .btn-custom:focus,
    .btn-custom:active {
        background-color: #106936 !important;
        color: white !important;
    }

    .parent {
        display: grid;
        place-items: center;
        width: 100%;
        height: 100vh;
    }

    /* From Uiverse.io by Spacious74 */
    .box {
        min-width: 400px;
        border: solid 2px #8d8d8d;
        padding: 20px;
        border-radius: 20px;
        background-color: #fff;

    }

    .box:hover {
        box-shadow: 3px 9px 3px;
        transform: translateX(-3px) translateY(-9px);
        transition: all 0.3s ease-out;
    }

    .box .heading {
        font-size: 1.3rem;
        margin-bottom: 20px;
        font-weight: bolder;
        text-align: center;
    }

    .form {
        min-width: 400px;
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .form .btn-container {
        width: 100%;
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .form .btn {
        padding: 10px 20px;
        font-size: 1rem;
        text-transform: uppercase;
        letter-spacing: 3px;
        border-radius: 10px;
        border: solid 1px #026b30;
        border-bottom: solid 1px #017d37;
        background: linear-gradient(135deg, #078a40, #0b4925);
        color: #fff;
        font-weight: bolder;
        transition: all 0.2s ease;
        box-shadow: 0px 2px 3px, inset 0px 4px 5px #013819,
            inset 0px -4px 5px #013819;
    }

    .form .btn:active {
        box-shadow: inset 0px 4px 5px #026b30, inset 0px -4px 5px #013819;
        transform: scale(0.995);
    }

    .input-field {
        position: relative;
    }

    .input-field label {
        position: absolute;
        color: #8d8d8d;
        pointer-events: none;
        background-color: transparent;
        left: 15px;
        transform: translateY(0.6rem);
        transition: all 0.3s ease;
    }

    .input-field input {
        padding: 10px 15px;
        font-size: 1rem;
        border-radius: 8px;
        border: solid 1px #8d8d8d;
        letter-spacing: 1px;
        width: 100%;
    }

    .input-field input:focus,
    .input-field input:valid {
        outline: none;
        border: solid 1px #106936;
    }

    .input-field input:focus~label,
    .input-field input:valid~label {
        transform: translateY(-51%) translateX(-10px) scale(0.8);
        background-color: #fff;
        padding: 0px 5px;
        color: #106936;
        font-weight: bold;
        letter-spacing: 1px;
        border: none;
        border-radius: 100px;
    }

    .form .passicon {
        cursor: pointer;
        font-size: 1.3rem;
        position: absolute;
        top: 6px;
        right: 8px;
    }

    .form .close {
        display: none;
    }
</style>

<body>

    <div class="parent animate__animated animate__fadeIn">
        <div class=" box">
            <div class="heading">Entre em sua conta</div>
            <div class="">
                <!-- Alerta de erro -->
                <?php if (!empty($warningMessage)) : ?>
                    <div class="alert alert-warning" role="alert">
                        <?php echo $warningMessage; ?>
                    </div>
                <?php endif; ?>
                <form class="form" action="" method="post">
                    <div class="input-field">
                        <input required="true" autocomplete="off" type="text" name="Username" id="Username" />
                        <label for="Username">Usuário</label>
                    </div>
                    <div class="input-field">
                        <input required="true" autocomplete="off" type="password" name="senha" id="senha" />
                        <label for="username">Senha</label>
                    </div>

                    <div class="btn-container">
                        <button class="btn" type="submit">Login</button>
                    </div>
                </form>
            </div>
        </div>

</body>

<script>
    document.getElementById("loginForm").onsubmit = function(event) {
        console.log("Formulário enviado!");
    };
</script>

</html>