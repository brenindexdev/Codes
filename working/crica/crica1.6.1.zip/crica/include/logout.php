<?php
session_start(); // Inicia a sessão

// Destrói todas as variáveis de sessão
session_unset();

// Destroi a sessão
session_destroy();

// Verifique se a sessão foi destruída
if (session_status() == PHP_SESSION_NONE) {
    echo "Sessão destruída com sucesso!";
} else {
    echo "Erro ao destruir a sessão.";
}

// Redireciona para a página de login
header("Location: login.php");
exit;
