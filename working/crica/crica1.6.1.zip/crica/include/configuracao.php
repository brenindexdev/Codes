<?php
session_start();

// Verifica se as variáveis de sessão necessárias existem
if (!isset($_SESSION['Username']) || !isset($_SESSION['senha'])) {
    die("Erro: Sessão inválida. Faça login novamente.");
}

// Obtém o usuário e senha da sessão
$usuario = $_SESSION['Username'];
$senha = $_SESSION['senha'];
$database = 'crica';
$host = 'localhost';

// Define constantes para a conexão
define('DB_SERVIDOR', $host);
define('DB_BANCO', $database);
define('DB_USUARIO', $usuario);
define('DB_SENHA', $senha);

// Estabelece a conexão com o banco de dados
$dbc = @mysqli_connect(
    DB_SERVIDOR,
    DB_USUARIO,
    DB_SENHA,
    DB_BANCO
) or die('Não foi possível conectar ao MySQL: ' . mysqli_connect_error());
