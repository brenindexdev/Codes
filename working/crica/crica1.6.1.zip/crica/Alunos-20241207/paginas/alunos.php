<?php

include_once("configuracao.php");

$conexao = new mysqli($host, $usuario, $senha, $database);

if (isset($_GET['prontuario'])) {
  $resultado = mysqli_query($conexao, "select *  FROM alunos where prontuario_alu = '$_GET[prontuario]'");
  $busca = mysqli_fetch_row($resultado);
}

if (isset($_POST['salvar']) && !isset($_GET['prontuario'])) {

  $prontuario = $_POST['prontuario_alu'];;
  $nome = $_POST['nome_alu'];
  $data = $_POST['nascimento_alu'];
  $cpf = $_POST['cpf_alu'];
  $fone = $_POST['fone_alu'];
  $email = $_POST['email_alu'];

  $resultado = mysqli_query($conexao, "insert into alunos (prontuario_alu,nome_alu,nascimento_alu,cpf_alu,fone_alu,email_alu)
              values('$prontuario','$nome','$data','$cpf','$fone','$email')");

  if (!$resultado)
    echo "Erro ao gravar no arquivo alunos";

  header("location: alunos.php");
}

if (isset($_POST['salvar']) && isset($_GET['prontuario'])) {

  $prontuario = $_GET['prontuario'];;
  $nome = $_POST['nome_alu'];
  $data = $_POST['nascimento_alu'];
  $cpf = $_POST['cpf_alu'];
  $fone = $_POST['fone_alu'];
  $email = $_POST['email_alu'];

  $resultado = mysqli_query($conexao, "update alunos set 
                                 nome_alu='$nome' , 
                                 nascimento_alu='$data' , 
                                 cpf_alu='$cpf' , 
                                 fone_alu='$fone' , 
                                 email_alu='$email'
                                 where prontuario_alu ='$prontuario'");

  if (!$resultado)
    echo "Erro ao atualizar o arquivo alunos";

  header("location: alunos.php");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script type="text/javascript" src="../javascript/validacao.js"></script>
</head>

<body>
  <form action="" method="POST">
    <center>
      <table>
        <tr>
          <td colspan="2">
            <nav class="navbar navbar-light bg-light">
              <div class="container">

                <!-- novo -->
                <a class="navbar-brand" href="alunos.php">
                  <i class="bi bi-file-earmark"></i>
                </a>

                <!-- abrir -->
                <a class="navbar-brand" href="pesquisa_alunos.php">
                  <i class="bi bi-folder2-open"></i>
                </a>

                <!-- sair -->
                <a class="navbar-brand" href="../index.php">
                  <i class="bi bi-door-open"></i>
                </a>
              </div>
            </nav>
          </td>
        <tr>

        <tr>
          <td><label>Prontuário</label></td>
          <td><input type="text" name="prontuario_alu" required
              value="<?php
                      if (isset($_GET['prontuario'])) {
                        echo $busca[0];
                      }
                      ?>"></td>
        </tr>
        <tr>
          <td><label>Nome</label>
          <td><input type="text" name="nome_alu" required
              value="<?php
                      if (isset($_GET['prontuario'])) {
                        echo $busca[1];
                      }
                      ?>">
        </tr>
        <tr>
          <td><label>Nascimento</label></td>
          <td><input type="date" name="nascimento_alu"
              value="<?php
                      if (isset($_GET['prontuario'])) {
                        echo  substr($busca[2], 0, 10);
                      }
                      ?>"></td>
        </tr>
        <tr>
          <td><label>CPF</label></td>
          <td><input type="text" name="cpf_alu" maxlength="14"
              onkeypress="formatar_cpf(this)"
              value="<?php
                      if (isset($_GET['prontuario'])) {
                        echo $busca[3];
                      }
                      ?>"></td>
        </tr>
        <tr>
          <td><label>Fone</label></td>
          <td><input type="text" name="fone_alu" placeholder="(__)_____-____" maxlength="14" onkeyup="formatar_telefone(this)"
              value="<?php
                      if (isset($_GET['prontuario'])) {
                        echo $busca[4];
                      }
                      ?>"></td>
        </tr>
        <tr>
          <td><label>E-mail</label></td>
          <td><input type="text" name="email_alu"
              value="<?php
                      if (isset($_GET['prontuario'])) {
                        echo $busca[5];
                      }
                      ?>"></td>
        </tr>
        <tr>
          <td colspan="2">
            <nav class="navbar navbar-light bg-light">
              <div class="container">
                <!-- salvar -->
                <button type="submit" name="salvar" class="navbar-brand">
                  <i class="bi bi-floppy2-fill"></i>
                </button>

                <?php
                if (isset($_GET['prontuario'])) {
                  echo "<!-- apagar -->
                      <a class='navbar-brand' href='deleta_alunos.php?prontuario=$_GET[prontuario]'>
                      <i class='bi bi-trash'></i>
                      </a>";
                }
                ?>

                <!-- cancelar -->
                <a class="navbar-brand" href="alunos.php">
                  <i class="bi bi-arrow-counterclockwise"></i>
                </a>
              </div>
            </nav>
          </td>
        <tr>
      </table>
  </form>
  </center>
</body>

</html>