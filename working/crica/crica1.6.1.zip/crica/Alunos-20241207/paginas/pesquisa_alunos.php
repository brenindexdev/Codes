<?php 

  include_once("configuracao.php");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="../javascript/validacao.js"></script>
  </head>
<body>
<form action="" method="POST">
<center>
<table>
  <tr>
    <td colspan="2">
      <nav class="navbar navbar-light bg-light">
        <div class="container">
        
        <!-- sair -->
        <a class="navbar-brand" href="alunos.php">
        <i class="bi bi-door-open"></i>
        </a>
      </div>
    </nav>
    </td>
  <tr>

  <tr>
    <td><label >Prontuário</label></td>
    <td><input type="text" name="prontuario_alu"></td>
</tr>
<tr>
  <td><label >Nome</label>
  <td><input type="text" name="nome_alu">
</tr>
<tr>
  <td colspan="2">
  <nav class="navbar navbar-light bg-light">
    <div class="container">
      <right>
      <!-- pesquisar -->
      <button type="submit" name = "localizar" class="navbar-brand">
      <i class="bi bi-arrow-right-square"></i>
      </button>
    </div>
  </nav>
  </td>
<tr>  
</table>
</form>
<?php
 if  (isset($_POST['localizar']) ){
    
  $banco = 'alunos';

  $conexao = new mysqli($host,$usuario,$senha,$database);

  $prontuario = $_POST['prontuario_alu'] . "%";
  $nome = "%" . $_POST['nome_alu'] . "%";
  

  $resultado = mysqli_query($conexao, "select prontuario_alu , nome_alu  FROM alunos where prontuario_alu like '$prontuario' and
                  nome_alu like '$nome' order by nome_alu" ) ;
  if ($resultado)
    $mostra = True ;
  else
    $mostra = false; 

 if  (isset($mostra)){
  echo "<table>
          <thead>
            <tr>
              <th>Prontuário</th>
              <th>Nome do aluno</th>
            </tr>
          </thead>
          <tbody>
          ";
    
  while($busca = mysqli_fetch_row($resultado)){
    echo "<tr>
                 <td>$busca[0]</td>
                 <td>$busca[1]</td>
                 <td>
                   <a class='navbar-brand' href='alunos.php?prontuario=$busca[0]'>
                   <i class='bi bi-arrow-right-square'></i>
                   </a>
                 </td>
              </tr>" ;
  } // while
  echo "</tbody>
        </table>";
    } // if mostra
 } // post localizar
?>
</center>
</body>
</html>