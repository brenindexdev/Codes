<?php

require_once('../include/configuracao.php');  // Inclui a configuração da conexão

$erros = array();  // Inicializa um array de erros

// Verifica se o formulário foi enviado
if (isset($_POST['enviou'])) {

    // Verifica se existe um nome da sala
    if (empty($_POST['nome_sala'])) {
        $erros[] = "Você esqueceu de digitar o nome da sala.";
    } else {
        $nome = mysqli_real_escape_string($dbc, trim($_POST['nome_sala']));
    }

    // Verifica se existe uma capacidade da sala
    if (empty($_POST['capacidade_sala'])) {
        $erros[] = "Você esqueceu de digitar a capacidade da sala.";
    } else {
        $capacidade = mysqli_real_escape_string($dbc, trim($_POST['capacidade_sala']));
    }

    // Se não houver erros, atualiza a sala no banco de dados
    if (empty($erros)) {
        $codigo = $_POST['codigo_sala'];  // Recupera o ID da sala

        // Verifica se o ID é válido
        if (empty($codigo) || !is_numeric($codigo)) {
            $erros[] = "Parâmetro inválido. ID da sala não foi informado corretamente.";
        }

        if (empty($erros)) {
            // SQL de atualização
            $q = "UPDATE salas SET nome_sala = '$nome', capacidade_sala = '$capacidade' 
                  WHERE codigo_sala = '$codigo'";

            // Executa a consulta
            $r = @mysqli_query($dbc, $q);  // Agora usamos $dbc para a consulta

            if ($r) {
                // Se o update for bem-sucedido, exibe sucesso
                $sucesso = "<h1><b>Sucesso!</b></h1>
                <p>A sala foi atualizada com sucesso!</p>
                <p>Aguarde... Redirecionando!</p>";
                echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=pesquisa_salas.php'>";
            } else {
                // Se ocorrer algum erro no sistema, exibe mensagem de erro
                $erro = "<h1><b>Erro no Sistema</b></h1>
                <p>Ocorreu um erro no sistema.</p>";
                $erro .= "<p>" . mysqli_error($dbc) . "</p>";
            }
        }
    } else {
        // Se houver erros de validação, exibe os erros
        $erro = "<h1><b>Erro!</b></h1> 
        <p>Ocorreram o(s) seguinte(s) erro(s): <br />";
        foreach ($erros as $msg) {
            $erro .= "- $msg <br />";
        }
        $erro .= "</p><p>Por favor, tente novamente.</p>";
    }
}

// Verificar se o parâmetro 'codigo_sala' foi passado na URL e se é um número
if (isset($_GET['codigo_sala']) && is_numeric($_GET['codigo_sala'])) {
    $codigo = $_GET['codigo_sala'];  // Recupera o ID da sala passado via GET

    // Consulta os dados da sala
    $q = "SELECT * FROM salas WHERE codigo_sala = '$codigo'";
    $r = @mysqli_query($dbc, $q);  // Usando a conexão $dbc

    // Verifica se a sala foi encontrada
    if ($r && mysqli_num_rows($r) == 1) {
        $sala = mysqli_fetch_assoc($r);
    } else {
        echo "<h1><b>Erro!</b></h1> <p>Sala não encontrada.</p>";
        exit();
    }
} else {
    echo "<h1><b>Erro!</b></h1> <p>Parâmetro inválido.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edição de Sala</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-custom {
            background-color: #0b4925;
            color: white;
        }

        .btn-custom:hover {
            background-color: #053b1c;
            color: white;
        }

        .btn-custom:focus,
        .btn-custom:active {
            background-color: #106936 !important;
            color: white !important;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-container">
            <h2 class="text-center mb-4">Edição de Sala</h2>

            <?php
            if (isset($erro))
                echo "<div class='alert alert-danger'>$erro</div>";

            if (isset($sucesso))
                echo "<div class='alert alert-success'>$sucesso</div>";
            ?>

            <form method="post" action="editar_salas.php?codigo_sala=<?= $sala['codigo_sala']; ?>">
                <!-- Nome da Sala -->
                <div class="mb-3">
                    <label for="nome_sala" class="form-label">Nome da Sala</label>
                    <input type="text" class="form-control" id="nome_sala" name="nome_sala" required
                        placeholder="Digite o nome da sala" value="<?= $sala['nome_sala']; ?>">
                </div>
                <!-- Capacidade -->
                <div class="mb-3">
                    <label for="capacidade_sala" class="form-label">Capacidade</label>
                    <input type="number" class="form-control" id="capacidade_sala" name="capacidade_sala" required
                        placeholder="Digite a capacidade" value="<?= $sala['capacidade_sala']; ?>">
                </div>
                <!-- Botões de ação -->
                <div class="">
                    <button type="submit" name="enviou" class="btn btn-custom"><i class="fa-solid fa-floppy-disk"></i></button>
                    <a href="pesquisa_salas.php" class="btn btn-outline-secondary"><i class="fa-solid fa-ban"></i></a>
                </div>
                <input type="hidden" name="codigo_sala" value="<?= $sala['codigo_sala'] ?>"> <!-- Campo oculto para passar o ID da sala -->
            </form>
        </div>
    </div>
</body>

</html>