<?php
include_once("../include/configuracao.php");


// Verifica se o codigo_sala foi passado por GET ou POST
if (isset($_GET['codigo_sala']) && is_numeric($_GET['codigo_sala'])) {
    $codigo = trim($_GET['codigo_sala']); // Remove espaços em branco
} else if (isset($_POST['codigo_sala']) && is_numeric($_POST['codigo_sala'])) {
    $codigo = trim($_POST['codigo_sala']); // Remove espaços em branco
} else {
    echo "<div class='alert alert-danger'>Código da sala não fornecido.</div>";
    exit();  // Encerra o script caso o código da sala não tenha sido passado.
}

// Verificação para saber se o código foi passado corretamente
echo "Código da sala: " . $codigo . "<br>"; // Para depuração, verifique se o código está correto

// Verifica se foi enviado o formulário de exclusão
if (isset($_POST['enviou'])) {

    // Verifique o tipo de dado de $codigo, certificando-se de que ele é um número inteiro
    $codigo = (int) $codigo;  // Converte a variável para inteiro

    // SQL para exclusão
    $q = "DELETE FROM salas WHERE codigo_sala = $codigo";

    // Exibe a consulta para depuração
    echo "Consulta de exclusão: $q";

    $r = @mysqli_query($dbc, $q);

    if ($r) {
        $sucesso = "<h1><b>Sala excluída!<b/><h1/>";
        $sucesso .= "<p>Aguarde... Redirecionando!</p>";
        echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=pesquisa_salas.php'>";
    } else {
        $erro = "<h1><b>Erro no Sistema</b></h1>
             <p>Ocorreu um erro ao tentar excluir a sala.</p>";
        $erro .= "<p>" . mysqli_error($dbc) . "</p>";
    }
}

// Pesquisa para exibir o registro da sala para exclusão
$q = "SELECT * FROM salas WHERE codigo_sala = $codigo";
$r = @mysqli_query($dbc, $q);

// Verifica se o código da sala existe no banco
if (mysqli_num_rows($r) == 1) {
    $row = mysqli_fetch_array($r, MYSQLI_ASSOC);
?>

    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Exclusão de Sala</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <style>
            body {
                background-color: #f8f9fa;
            }

            .form-container {
                max-width: 500px;
                margin: 50px auto;
                padding: 20px;
                background: white;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .btn-custom {
                background-color: #0b4925;
                color: white;
            }

            .btn-custom:hover {
                background-color: #053b1c;
                color: white;
            }

            .btn-custom:focus,
            .btn-custom:active {
                background-color: #106936 !important;
                color: white !important;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div class="form-container">
                <h2 class="text-center mb-4">Exclusão de Sala</h2>

                <?php
                if (isset($erro))
                    echo "<div class='alert alert-danger'>$erro</div>";
                ?>

                <form method="post" action="deleta_salas.php">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="nome_sala">Nome</label>
                            <input type="text" class="form-control" id="nome_sala" name="nome_sala" disabled
                                value="<?= $row['nome_sala']; ?>" />
                        </div>
                        <div class="form-group col-md-12">
                            <label for="capacidade_sala">Capacidade</label>
                            <input type="number" class="form-control" id="capacidade_sala" name="capacidade_sala" disabled
                                value="<?= $row['capacidade_sala']; ?>" />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 text-right">
                            <a href="pesquisa_salas.php" class="btn btn-secondary"><i class="fa-solid fa-ban"></i> Fechar</a>
                            <input type="submit" value="Excluir" class="btn btn-danger" />
                        </div>
                    </div>
                    <input type="hidden" name="enviou" value="true" />
                    <input type="hidden" name="codigo_sala" value="<?= $row['codigo_sala']; ?>" />
                </form>
            </div>
        </div>
    </body>

    </html>

<?php
} else {
    // Caso o codigo_sala não seja encontrado
    echo "<div class='alert alert-danger'>Sala não encontrada.</div>";
}
?>