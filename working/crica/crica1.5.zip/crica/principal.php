<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Principal - Sistema Acadêmico</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome para ícones -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        .btn-custom,
        .btn-custom:hover {
            width: 100%;
            height: 80px;
            font-size: 20px;
            background-color: #0b4925;
            color: white;
        }

        .btn-custom:focus,
        .btn-custom:active {
            background-color: #106936 !important;
            color: white !important;
        }

        .dropdown-menu,
        .dropdown-menu:active,
        .dropdown-menu:focus {
            width: 100%;
            background-color: #106936 !important;

        }

        .btn-exit {
            background-color: #ff4d4d;
            color: white;
        }

        .btn-exit:hover {
            background-color: #e43d3d;
        }

        .modal-body {}
    </style>
</head>

<body class="d-flex justify-content-center align-items-center vh-100">

    <div class="container text-center">

        <!-- Menu de opções principal -->
        <div class="row g-3">
            <!-- Alunos Dropdown -->
            <div class="col-md-4 col-sm-6">
                <button class="btn btn-custom" type="button" aria-expanded="false" href="#" data-bs-toggle="modal" data-bs-target="#alunosModal">
                    <i class="fa-solid fa-graduation-cap mx-2"></i>Alunos
                </button>
                <div class="modal fade" id="alunosModal" tabindex="-1" aria-labelledby="alunosModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-body d-flex row">
                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cadastro
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Boletim
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Matrícula
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Disciplinas
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Curso
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Grade Curricular
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cursos Dropdown -->
            <div class="col-md-4 col-sm-6">
                <button class="btn btn-custom" type="button" aria-expanded="false" href="#" data-bs-toggle="modal" data-bs-target="#cursosModal">
                    <i class="fa-solid fa-code mx-2"></i>Cursos
                </button>
                <div class="modal fade" id="cursosModal" tabindex="-1" aria-labelledby="cursosModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-body d-flex row">
                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cadastro
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Disciplinas
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Alunos
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Professor
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Horários
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Salas
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Disciplinas Dropdown -->
            <div class="col-md-4 col-sm-6">
                <button class="btn btn-custom" type="button" aria-expanded="false" href="#" data-bs-toggle="modal" data-bs-target="#disciplinasModal">
                    <i class="fa-solid fa-book mx-2"></i>Disciplinas
                </button>
                <div class="modal fade" id="disciplinasModal" tabindex="-1" aria-labelledby="disciplinasModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-body d-flex row">
                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cadastro
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Professores
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Horário
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Salas
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cursos
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Alunos
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Professores Dropdown -->
            <div class="col-md-4 col-sm-6">
                <button class="btn btn-custom" type="button" aria-expanded="false" href="#" data-bs-toggle="modal" data-bs-target="#professoresModal">
                    <i class="fa-solid fa-chalkboard-user mx-2"></i>Professores
                </button>
                <div class="modal fade" id="professoresModal" tabindex="-1" aria-labelledby="professoresModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-body d-flex row">
                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cadastro
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Disciplinas
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Boletim
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cursos
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Alunos
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Horários
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Horários Dropdown -->
            <div class="col-md-4 col-sm-6">
                <button class="btn btn-custom" type="button" aria-expanded="false" href="#" data-bs-toggle="modal" data-bs-target="#horariosModal">
                    <i class="fa-solid fa-clock mx-2"></i>Horários
                </button>
                <div class="modal fade" id="horariosModal" tabindex="-1" aria-labelledby="horariosModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-body d-flex row">
                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cadastro
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Grade
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Professores
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Disciplinas
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Salas
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Alunos
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Salas Dropdown -->
            <div class="col-md-4 col-sm-6">
                <button class="btn btn-custom" type="button" aria-expanded="false" href="#" data-bs-toggle="modal" data-bs-target="#salasModal">
                    <i class="fa-solid fa-door-open mx-2"></i>Salas
                </button>
                <div class="modal fade" id="salasModal" tabindex="-1" aria-labelledby="salasModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-body d-flex row">
                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Cadastro
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Mapa
                                    </button>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Professores
                                    </button>
                                </div>

                                <div class="col-md-6 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Disciplinas
                                    </button>
                                </div>

                                <div class="col-md-6 col-sm-6">
                                    <button class="btn btn-custom" type="button" aria-expanded="false" href="#">
                                        <i class="fa-solid fa- "></i>Curso
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sair com ícone -->

        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>