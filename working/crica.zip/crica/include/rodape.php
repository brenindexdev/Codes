<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Rodapé</title>
    <style>
        body {
            background-color: #072D17;
        }

        span {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: small;
            opacity: 75%;
            color: white;
            margin: 3px;
        }
    </style>
</head>

<body>
    <div class="d-flex">
        <div class="col-md-6 text-start mt-1">
            <span>© Todos os Direitos Reservados</span>
            <a href=""><span>Termos de Uso</span></a>
        </div>
        <div class="col-md-6 text-end mt-1">
            <span>By:</span>
            <span>Nome 1</span>
            <span>Nome 2</span>
            <span>Nome 3</span>
            <span>Nome 4</span>
        </div>
    </div>
    </div>

    <!-- Bootstrap JS e Font Awesome -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>