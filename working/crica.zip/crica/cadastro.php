<?php 
    include_once('../../cabecalho.php');


    if (isset($_POST['enviou'])) {

        require_once('conexao.php');

        $erros = array();

        //Verifica se existe um protuário
        if (empty($_POST['protuario_alu'])) {
            $erros[] = "Você esqueceu de digitar o prontuário.";
        } else {
            $t = mysqli_real_escape_string($dbc, trim(
                $_POST['protuario_alu']));
        }

        //Verifica se existe um nome
        if (empty($_POST['nome_alu'])) {
            $erros[] = "Você esqueceu de digitar o nome.";
        } else {
            $t = mysqli_real_escape_string($dbc, trim(
                $_POST['nome_alu']));
        }

        //Verifica se existe um nascimento
        if (empty($_POST['nascimento_alu'])) {
            $erros[] = "Você esqueceu de digitar o nascimento.";
        } else {
            $t = mysqli_real_escape_string($dbc, trim(
                $_POST['nascimento_alu']));
        }

        //Verifica se existe um cpf
        if (empty($_POST['cpf_alu'])) {
            $erros[] = "Você esqueceu de digitar o CPF.";
        } else {
            $t = mysqli_real_escape_string($dbc, trim(
                $_POST['cpf_alu']));
        }
        
        //Verifica se existe um telefone
        if (empty($_POST['fone_alu'])) {
            $erros[] = "Você esqueceu de digitar o telefone.";
        } else {
            $t = mysqli_real_escape_string($dbc, trim(
                $_POST['fone_alu']));
        }

        //Verifica se existe um email
        if (empty($_POST['email_alu'])) {
            $erros[] = "Você esqueceu de digitar o e-mail.";
        } else {
            $t = mysqli_real_escape_string($dbc, trim(
                $_POST['email_alu']));
        }

        if (empty($erros)) {
            //SQL de inserção
            $q = "INSERT INTO alunos (prontuario_alu, nome_alu, nascimento_alu, cpf_alu, fone_alu, email_alu)
                VALUES ('$t', NOW())";
                
            $r = @mysqli_query($dbc, $q);

            if ($r) {
                $sucesso = "<h1><b>Sucesso!</b></h1>
                <p>Seu registro foi incluido com sucesso!</p>
                <p>Aguarde... Redirecionando!</p>";
                echo "<meta HTTP-EQUIV='refresh' 
                    CONTENT='3;URL=principal.php'>";
            } else {
                $erro = "<h1><b>Erro no Sistema</b></h1>
                <p>Ocorreu um erro no sistema.</p>";
                $erro .= "<p>" . mysqli_error($dbc) . "</p>";
            }
        } else {
            $erro = "<h1><b>Erro!</b></h1> 
            <p>Ocorreram o(s) seguinte(s) erro(s): <br />";
            foreach ($erros as $msg) {
                $erro .= "- $msg <br />";
            }
            $erro .= "</p><p>Por favor, tente novamente.</p>";
        }
    }
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Aluno - Cadastro</h1>
</div>

<?php 
    if (isset($erro))
        echo "<div class='alert alert-danger'>$erro</div>";

    if (isset($sucesso))
        echo "<div class='alert alert-success'>$sucesso</div>";        
?>

<form method="post" action="cadastro.php">
    <div class="row">
        <div class="form-group col-md-12">
            <label>Título</label>
            <input type="text" name="titulo" maxlength="60"
                class="form-control"
                placeholder="Digite o título" 
                value="<?php if (isset($_POST['titulo'])) 
                    echo $_POST['titulo']; ?>" />
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 text-right">
            <a href="categoria_menu.php" class="btn btn-secondary">
                Fechar sem Salvar</a>
            <input type="submit" value="Salvar"
                class="btn btn-primary" />
        </div>
    </div>
    <input type="hidden" name="enviou" value="true" />
</form>

<?php 
    include_once('../include/rodape_admin.php');
?>