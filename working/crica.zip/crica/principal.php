<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Principal - Sistema Acadêmico</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome para ícones -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        body {
            margin: 20px;
            font-family: Arial, sans-serif;
        }

        .menu-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
        }

        .menu-item {
            flex: 1 1 200px;
        }

        .btn-custom {
            width: 100%;
            padding: 15px;
            font-size: 18px;
        }

        .btn-exit {
            background-color: #ff4d4d;
            color: white;
        }

        .btn-exit:hover {
            background-color: #e43d3d;
        }
    </style>
</head>

<body>

    <div class="container text-center">
        <h1 class="mb-5">Menu de Opções Principal</h1>

        <!-- Menu de opções principal -->
        <div class="menu-container">
            <!-- Alunos Dropdown -->
            <div class="menu-item">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle btn-custom" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Alunos
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="cadastro.php">Cadastro</a></li>
                        <li><a class="dropdown-item" href="#">Boletim</a></li>
                        <li><a class="dropdown-item" href="#">Matrícula</a></li>
                        <li><a class="dropdown-item" href="#">Disciplinas</a></li>
                        <li><a class="dropdown-item" href="#">Curso</a></li>
                        <li><a class="dropdown-item" href="#">Grade Curricular</a></li>
                    </ul>
                </div>
            </div>

            <!-- Cursos Dropdown -->
            <div class="menu-item">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle btn-custom" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Cursos
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Cadastro</a></li>
                        <li><a class="dropdown-item" href="#">Disciplinas</a></li>
                        <li><a class="dropdown-item" href="#">Alunos</a></li>
                        <li><a class="dropdown-item" href="#">Professor</a></li>
                        <li><a class="dropdown-item" href="#">Horários</a></li>
                        <li><a class="dropdown-item" href="#">Salas</a></li>
                    </ul>
                </div>
            </div>

            <!-- Disciplinas Dropdown -->
            <div class="menu-item">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle btn-custom" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Disciplinas
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Cadastro</a></li>
                        <li><a class="dropdown-item" href="#">Professores</a></li>
                        <li><a class="dropdown-item" href="#">Horário</a></li>
                        <li><a class="dropdown-item" href="#">Salas</a></li>
                        <li><a class="dropdown-item" href="#">Cursos</a></li>
                        <li><a class="dropdown-item" href="#">Alunos</a></li>
                    </ul>
                </div>
            </div>

            <!-- Professores Dropdown -->
            <div class="menu-item">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle btn-custom" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Professores
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Cadastro</a></li>
                        <li><a class="dropdown-item" href="#">Disciplinas</a></li>
                        <li><a class="dropdown-item" href="#">Boletim</a></li>
                        <li><a class="dropdown-item" href="#">Cursos</a></li>
                        <li><a class="dropdown-item" href="#">Alunos</a></li>
                        <li><a class="dropdown-item" href="#">Horários</a></li>
                    </ul>
                </div>
            </div>

            <!-- Horários Dropdown -->
            <div class="menu-item">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle btn-custom" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Horários
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Cadastro</a></li>
                        <li><a class="dropdown-item" href="#">Grade</a></li>
                        <li><a class="dropdown-item" href="#">Professores</a></li>
                        <li><a class="dropdown-item" href="#">Disciplinas</a></li>
                        <li><a class="dropdown-item" href="#">Salas</a></li>
                        <li><a class="dropdown-item" href="#">Alunos</a></li>
                    </ul>
                </div>
            </div>

            <!-- Salas Dropdown -->
            <div class="menu-item">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle btn-custom" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Salas
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Cadastro</a></li>
                        <li><a class="dropdown-item" href="#">Mapa</a></li>
                        <li><a class="dropdown-item" href="#">Professores</a></li>
                        <li><a class="dropdown-item" href="#">Disciplinas</a></li>
                        <li><a class="dropdown-item" href="#">Curso</a></li>
                    </ul>
                </div>
            </div>

            <!-- Sair com ícone -->
            <div class="menu-item">
                <a href="logout.php" class="btn btn-exit btn-custom">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>