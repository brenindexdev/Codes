<?php

    require_once('includes/conexao.php');

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $id = mysqli_real_escape_string($dbc, $id);
    
        $q = "SELECT * FROM filmes WHERE id = '$id'";
        $r = @mysqli_query($dbc, $q);
        $reg = mysqli_fetch_array($r, MYSQLI_ASSOC);
    
        $nome = $reg["nome"];
        $diretor = $reg["diretor"];
        $atores = $reg["atores"];
        $lancamento = $reg["lancamento"];
        $classificacao = $reg["classificacao"];
        $duracao = $reg["duracao"];
        $resumo = $reg["resumo"];
        $sessao = $reg["sessao"];
        $capa = $reg["capa"];
    } else {
        echo 'Erro: Parâmetro "id" não foi passado.';
        exit;
    }

    $titulo = "Detalhes: " . $nome;
    include_once('includes/cabecalho_site.php');
?>

<div class="justify-content-end mb-3">
            <div> <a href="index.php"> <img class="mr-1" href="index.php" src="filmes/arrow-left-circle.svg">Voltar</a></div>
</div>

<div class="row">
    <div class="col-md-9 jumbotron">
        <div class="row">
            <div class="col-md-12">
                <h3><b><?= $nome; ?></b></h3>
                <h4>Diretor: <b><?= $diretor; ?></b></h4>
                <h4>Atores: <b><?= $atores; ?></b></h4>
                <h6><b>Data de publicação: </b><?= $lancamento; ?></h6>
                <h6 class="mb-4"><b>Resumo</b><br> <?= $resumo; ?></h6>
                
            </div>
            <div class="container row justify-content-center">
                <div class="col-md-4 text-center">
                    <h6><b>Classificação:</b><br>
                        <?php
                            if($classificacao == 0) {
                            echo('Livre');
                            }
                            else {
                            echo($classificacao);
                            }?></h6>
                </div>
                <div class="col-md-4 text-center">
                    <h6><b>Duração:</b><br><?= $duracao; ?></h6>
                </div>
                <div class="col-md-4 text-center">
                    <h6><b>Tipo da Sessão:</b><br><?= $sessao; ?></h6>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <img src="filmes/<?= $capa; ?>" class="img-fluid" alt="Capa do filme">
    </div>
</div>
    