-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 16-Set-2024 às 12:53
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `prova2`
--
CREATE DATABASE IF NOT EXISTS `prova2` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `prova2`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `filmes`
--

CREATE TABLE `filmes` (
  `id` int(11) NOT NULL,
  `nome` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `diretor` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `resumo` text COLLATE utf8_unicode_ci NOT NULL,
  `duracao` int(11) NOT NULL,
  `lancamento` datetime NOT NULL,
  `atores` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `classificacao` int(11) NOT NULL,
  `capa` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sessao` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `filmes`
--

INSERT INTO `filmes` (`id`, `nome`, `diretor`, `resumo`, `duracao`, `lancamento`, `atores`, `classificacao`, `capa`, `sessao`) VALUES
(1, 'Os Fantasmas Ainda se Divertem', 'Tim Burton', 'Os Fantasmas Ainda se Divertem: Beetlejuice Beetlejuice reúne novamente três gerações da família Deetz na casa em Winter River após uma terrível tragédia. É em meio a essa confusão que Astrid (Jenna Ortega), filha de Lydia Deetz (Winona Ryder), encontra a misteriosa maquete da cidade no sótão convidado o extravagante fantasma Beetlejuice (Michael Keaton) a passar pelo portal para a vida após a morte. ', 104, '2024-09-05 11:44:52', ' Michael Keaton, Winona Ryder, Jenna Ortega', 14, 'fantasmas.jpg', 'Legendado'),
(2, 'Silvio', 'Marcelo Antunez', 'Baseado em fatos reais, \"Silvio\", dirigido por Marcelo Antunez, retrata o sequestro do icônico apresentador Silvio Santos, vivido por Rodrigo Faro. A trama se inicia 12 horas após o sequestro de sua filha (Polliana Aleixo), quando Silvio enfrenta uma nova crise: sua casa é invadida e ele é mantido como refém por sete horas. Diante dessa situação de extremo perigo, o apresentador precisa lutar pela sua vida e pela segurança de sua família, enquanto reflete sobre sua trajetória de vida, marcada por desafios e conquistas. As lembranças remontam à sua juventude, quando, aos 14 anos, começou a trabalhar como camelô, dando os primeiros passos em direção ao sucesso. O filme explora o lado humano de Silvio, que, mesmo em uma situação de vulnerabilidade, tenta proteger seu legado. Esse evento dramático marcou o Brasil e se tornou um dos momentos mais desafiadores na vida do apresentador, destacando sua resiliência e força interior.', 114, '2024-09-12 11:47:43', 'Rodrigo Faro, Paulo Gorgulho, Polliana Aleixo', 14, 'silvio.webp', 'Nacional'),
(3, 'Deadpool & Wolverine', 'Shawn Levy', 'Deadpool & Wolverine reúne o icônico mercenário tagarela Wade Wilson (Ryan Reynolds) e o poderoso mutante Wolverine (Hugh Jackman) em uma aventura explosiva, escrita e produzida pelos mesmos talentos por trás de Deadpool (2016) e Deadpool 2 (2018). Wade Wilson desfruta de um momento de aparente calma ao lado de Vanessa (Morena Baccarin) e seus amigos e, em contra partida, Wolverine se recupera de seus ferimentos. Um têm os seus caminhos cruzados com o outro, dando início a uma improvável aliança. Juntos, eles enfrentam um inimigo formidável em comum, desencadeando uma jornada repleta de ação, humor e reviravoltas surpreendentes. Deadpool & Wolverine promete ser uma aventura épica, cheia de referências aos quadrinhos e momentos de pura adrenalina, proporcionando aos fãs uma experiência única e inesquecível no universo dos super-heróis.', 167, '2024-07-25 11:50:58', 'Ryan Reynolds, Hugh Jackman, Emma Corrin', 18, 'deadpool.webp', 'Legendado'),
(4, 'Meu Malvado Favorito 4', 'Patrick Delage, Chris Renaud', 'Nesta sequência, o vilão mais amado do planeta, que virou agente da Liga Antivilões, retorna para mais uma aventura em Meu Malvado Favorito 4. Agora, Gru (Leandro Hassum), Lucy (Maria Clara Gueiros), Margo (Bruna Laynes), Edith (Ana Elena Bittencourt) e Agnes (Pamella Rodrigues) dão as boas-vindas a um novo membro da família: Gru Jr., que pretende atormentar seu pai. Enquanto se adapta com o pequeno, Gru enfrenta um novo inimigo, Maxime Le Mal (Jorge Lucas) que acaba de fugir da prisão e agora ameaça a segurança de todos, forçando sua namorada mulher-fatal Valentina (Angélica Borges) e a família a fugir do perigo. Em outra cidade, as meninas tentam se adaptar ao novo colégio e Valentina incentiva Gru a tentar viver uma vida mais simples, longe das aventuras perigosas que fez durante quase toda a vida. Neste meio tempo, eles também conhecem Poppy (Lorena Queiroz), uma surpreendente aspirante à vilã e os minions dão o toque que faltava para essa nova fase. ', 94, '2024-07-25 11:53:58', 'Steve Carell, Kristen Wiig, Pierre Coffin', 0, 'malvado4.webp', 'Dublado'),
(5, 'Divertida Mente 2', 'Kelsey Mann', 'Quando Riley (Kaitlyn Dias) chega a tão temida adolescência as já conhecidas, Alegria (Amy Poehler), Tristeza (Phyllis Smith), Raiva, Medo (Tony Hale) e Nojinho (Liza Lapira), que há muito tempo administram uma operação bem-sucedida, não têm certeza de como se sentir quando novos inquilinos chegam ao local, sendo um deles a tão temida Ansiedade (Maya Hawke). ', 96, '2024-06-20 12:05:14', 'Miá Mello, Amy Poehler, Isabella Guarnieri', 0, 'divertidamente2.webp', 'Dublado');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `filmes`
--
ALTER TABLE `filmes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `filmes`
--
ALTER TABLE `filmes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
