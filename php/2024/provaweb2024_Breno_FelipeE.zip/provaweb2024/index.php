<?php
   $titulo = "Avaliação 2";

   include_once('includes/cabecalho_site.php');
   require_once('includes/conexao.php');

   //Numero de registros mostrados por pagina
   $exiba = 10;

   //Captura a pesquisa
   $where = isset($_GET['q']) ? mysqli_real_escape_string($dbc, trim($_GET['q'])) : '';

   //Determina quantas páginas existem
   if (isset($_GET['p']) && is_numeric($_GET['p'])) {
       $pagina = $_GET['p'];
   } else {
       //Contar a quantidade de registros
       $q = "SELECT COUNT(id) FROM filmes WHERE nome like '%$where%'";
       $r = @mysqli_query($dbc, $q);
       $row = @mysqli_fetch_array($r, MYSQLI_NUM);
       $qtde = $row[0];

       //calcular o numero de pagina
       if ($qtde > $exiba) {
           $pagina = ceil($qtde / $exiba);
       } else {
           $pagina = 1;
       }
   }

   //Determina a posição no BD para retornar os resultados
   if (isset($_GET['s']) && is_numeric($_GET['s'])) {
       $inicio = $_GET['s'];
   } else {
       $inicio = 0;
   }

   //Determina a ordenação, por padrão é por código
   $ordem = isset($_GET['ordem']) ? $_GET['ordem'] : 'id';

   //Determina a ordem de classificação
   switch ($ordem) {
       case 'codigo' :
           $order_by = 'id';
           break;
       case 'n' :
           $order_by = 'nome';
           break;
       case 'a' :
           $order_by = 'atores';
           break;
       case 'dir' :
           $order_by = 'diretor';
           break;
       case 'dur' :
           $order_by = 'duracao';
           break;
       default :
           $ordem = 'id';
           $order_by = 'id';
           break;
       }

   $q = "SELECT id, nome, atores, diretor, duracao FROM filmes WHERE nome like '%$where%' ORDER BY $order_by LIMIT $inicio, $exiba";
   $r = @mysqli_query($dbc, $q);

    if (mysqli_num_rows($r) > 0) {
        $saida = "<div class='table-responsive col-12'>
        <table class='table table-striped'>
            <thead>
                <tr>    
                    <th>Código</th>
                    <th>Nome</th>
                    <th>Atores</th>
                    <th>Diretor</th>
                    <th>Duração</th>
                    <th>Ações</th>
                </tr>
                </thead>
            <tbody>";
        while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC))
        {
            $saida .= "<tr>
                        <td>" . $row['id'] . "</td>" .
                        "<td>" . $row['nome'] . "</td>" .
                        "<td>" . $row['atores'] . "</td>" .
                        "<td>" . $row['diretor'] . "</td>" .
                        "<td>" . $row['duracao'] . "</td>" .
                        "<td class='text-center'>
                            <a href='filme.php?id=".$row['id']."' 
                                class='btn btn-sm btn-success'>Abrir</a>
                        </td>
                       </tr>";
        }
        $saida .= "</tbody></table>";
    } else {
        $saida = "<div class='alert alert-warning'>
        Não existe registro na tabela.
        </div>";
 }


?>
<div class="container">
    <h1>Lista de Filmes</h1><br />
</div>
<?php echo $saida; ?>

<?php
    include_once('includes/rodape.php');
?>